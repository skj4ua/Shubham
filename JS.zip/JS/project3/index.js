// console.log("Welcome to project 3");
// // 3f3a7b9adf264c83837d35aed96551e6
//      
//     let source = "bbc-news";
//     let apiKey = "3f3a7b9adf264c83837d35aed96551e6"
//     // xhr.open('GET', 'harry.txt', true);
//     // xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1', true);
//     const xhr = new XMLHttpRequest();
//     xhr.open('GET',`https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${apiKey}`, true);



//     // What to do when response is ready

//     xhr.onload = function()
//     {   // Http status codes 200 --> ok  404 --> Path Not found
//          if(this.status === 200)
//         // console.log(this.responseText);
//         obj = JSON.parse(this.responseText);
//         else
//         console.log("some error occured");
//     }

//     xhr.send();
//     console.log("We are done");







console.log("This is my index js file");




// Initialize the news api parameters

let source = 'bbc-news';

let apiKey = '3f3a7b9adf264c83837d35aed96551e6 '




// Grab the news container

let newsAccordion = document.getElementById('newsAccordion');




// Create an ajax get request

const xhr = new XMLHttpRequest();

// xhr.open('GET', `https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${apiKey}`, true);
xhr.open('GET', 'harry.txt', true)

// What to do when response is ready

xhr.onload = function () {

    if (this.status === 200) {

        let json = JSON.parse(this.responseText);
        // console.log(json);
        let articles = json.articles;

        console.log(articles);

        let newsHtml = "";

        articles.forEach(function (element, index) {

            // console.log(element, index)

            let news = `<div class="card">

                            <div class="card-header" id="heading${index}">

                                <h2 class="mb-0">

                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse${index}"

                                    aria-expanded="false" aria-controls="collapse${index}">

                                   <b>Breaking News ${index + 1}:</b> ${element["title"]}

                                </button>

                                </h2>

                            </div>




                            <div id="collapse${index}" class="collapse" aria-labelledby="heading${index}" data-parent="#newsAccordion">

                                <div class="card-body"> ${element["content"]}. <a href="${element['url']}" target="_blank" >Read more here</a>  </div>

                            </div>

                        </div>`;

            newsHtml += news;

        });

        newsAccordion.innerHTML = newsHtml;

    }

    else {

        console.log("Some error occured")

    }

}




xhr.send()



















