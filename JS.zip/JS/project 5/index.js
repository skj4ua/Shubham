console.log("We are in Project 5");
let data = [
    {
        Name:"Jenifer Sharma",
        age:18,
        city:"Nagpur",
        language:"Python",
        framework:"Django",
        image:"https://randomuser.me/api/portraits/women/68.jpg"



    },
    {
        Name:"Srushti Bhat",
        age:19,
        city:"Akola",
        language:"JavaScript",
        framework:"React",
        image:"https://randomuser.me/api/portraits/women/70.jpg"



    },
    {
        Name:"Henri David",
        age:22,
        city:"America",
        language:"JavaScript",
        framework:"Angular",
        image:"https://randomuser.me/api/portraits/women/90.jpg"



    },

    {
        Name:"Hemani Lakhani",
        age:20,
        city:"Nagpur",
        language:"Microsoft",
        framework:"C#",
        image:"https://randomuser.me/api/portraits/women/75.jpg"



    },
    {
        Name:"Kriti Sanon",
        age:25,
        city:"Mumbai",
        language:"Manual Testing",
        framework:"Software Tool",
        image:"https://randomuser.me/api/portraits/women/80.jpg"



    }
]

let nextIndex = 0;
// console.log(data);
function iterator(values) {
    return {
        next: function () {
            if (nextIndex < values.length) {
                return {
                    value: values[nextIndex++],
                    done: false
                }
            }
            else {
                return {
                    // value: values[nextIndex++],
                    done: true
                }
                // return
                // {
                //     done:true
                // }
                   
            }
        }
    }
}


let addBtn = document.getElementById("addBtn");
let image = document.getElementById("image");
let profile = document.getElementById("profile");
let currentValue  = iterator(data);
project(); 
addBtn.addEventListener("click",project)

function project(e){
    // e.preventDefault();
    const  currentCandidate = currentValue.next().value 
    // console.log(currentCandidate.image);  
    // <li class="list-group-item active">${currentCandidate.Name}</li> 
    if (currentCandidate != undefined)
    {
    image.innerHTML = `<img src='${currentCandidate.image}'>`
    profile.innerHTML = `<ul class="list-group">
    <li class="list-group-item active">${currentCandidate.Name}</li>
     
    <li class="list-group-item">${currentCandidate.age}</li>
    <li class="list-group-item">${currentCandidate.city}</li>
    <li class="list-group-item">${currentCandidate.language}</li>
    <li class="list-group-item">${currentCandidate.framework}</li>
  </ul>`
    }
    else{
        alert("End of the application");
    }
}
