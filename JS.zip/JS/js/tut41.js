console.log("This is tut41");
//  a = [1,2,3,4,5];
//  a.forEach(function(element,index) {
//      console.log(element,index);
//  });

//  a.forEach((element,index)  => {
//     console.log(element,index );
//  });


// converting a regular function
//  function Harry(){
//      console.log("Hello Good Morning!!!")
//  }

//  let b = function() {
//      return("Hello");
//  }

//  Harry();
//  console.log(b());

let b = () => {
    return ("Hello");
}

console.log(b());


// one liner statement do not braces/return
// one line will automatically retun

// const greet = ()=>   "Good Morning"; /// not require return and braces for one liner one line will automatically retun 


// const greet = ()=>{ return  "Good Morning"} // if writing return for ine liner the braces are must




// return an object

// const greet = ()=> ({name:"Shubham"});

const greet = (name,ending) => "Good Morning " + name + " " + ending

// two agrument hence need to use braces // Single parameter do not parathensis

console.log(greet("shubham",'bye'));






