/* Promises 
1)resolve 
2)reject
3)pending 
*/

// function func1()
// {
//     return new Promise(function (resolve,reject){
//         setTimeout(() => {
//             let error = false;
//             if(!error)
//             {
//                 console.log("Function : Your promise has been resolved");
//                 resolve("Hello Harry!!!!");
//             }
//             else{
//                 console.log("Function : Your promise has not been resolved");
//                 reject()
//             }
            
//         }, 1000);
//     })
     
// }

// func1().then(function(message){
//     console.log("Harry : Thanks for resolving",message)
// }).catch(function(){
//     console.log("Harry : Very bad Bro")   
// })



let promise = new Promise(function(resolve,reject){
 let x =1;
 let y =2;
 if(x==y)
 {  
    console.log("x and y are equal");
     resolve("both the values are identical");
 }
 else{
    console.log("x and y are  not equal") 
     reject("both the values are different");
 }

})

promise.then(function(successmesaage){
    console.log(successmesaage);
}).catch(function(errormesaage){
    console.log(errormesaage);
})