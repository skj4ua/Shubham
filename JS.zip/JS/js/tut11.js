// Documment object model
// console.log("This is tut11")
//a = window;
//alert("Hello harry");
// a = prompt("What is ur name")
//a = confirm("Are you want to delete");
//a = window.innerHeight;
// a = window.innerWidth;
// a = window.scrollX;
// a = scrollY;
// a = location;
// a = location.toString();
// a = history;
// console.log(a);

 

// const { number } = require("prop-types");/

// let a;
// (function(){
//     console.log(typeof b)
//     var a=b=3
//     console.log('the no is' ,a)
//   })();
  
// //   console.log("a defined? " + (typeof a == 'undefined'));
//         console.log(typeof a)
//   console.log("b defined? " + (typeof b !== 'undefined'));
 
// console.log(typeof a)


// let fruits = ["orange","apple","grapes","mango","apple","grapes"];

// let fruitsname = new Set(fruits)
// console.log(fruitsname)
// console.log(Array.from(fruitsname))


// let fruitsname = fruits.filter((ele,index) =>{
//     return fruits.indexOf(ele) == index
// })

// console.log()


// let count= 0
// let a = [1,2,1,2,3,6,2,1];
// let elem = a.reduce((acc,ele) =>{
// // console.log(ele)
// return (ele == 1 ? count+1:count)

// })

// console.log(elem)



// var ages = [32, 33, 16, 40];

// let agesname = ages.filter(ele =>{
//     return (ele > 18)
// })

// console.log(agesname)


// var myObject = {
//     foo: "bar",
//     func: function() {
//         var self = this;
//         console.log("outer func:  this.foo = " + this.foo);
//         console.log("outer func:  self.foo = " + self.foo);
//         (function name () {
//             console.log("inner func:  this.foo = " + this.foo);
//             console.log("inner func:  self.foo = " + self.foo);
//         }());
//     }
// };
// myObject.func();

// const name = 33
// console.log(Number.isNaN(4563))
// console.log(isNaN(name))





// console.log(0.1 + 0.2);
// console.log(0.1 + 0.2 == 0.3);

// let x=1,y=3
// x;
// ++y; 

// console.log(x)
// console.log(y)


// var a = 10



// console.log(a)




// function isPalindrome(str) {
//     str = str.replace(/\W/, '').toLowerCase();
//     console.log(str)
//     return (str == str.split('').reverse().join(''));
//   }


// //   console.log(isPalindrome("level"));                   // logs 'true'
// // console.log(isPalindrome("levels"));                  // logs 'false'
// console.log(isPalindrome("A car, a man, a maraca"));  // logs 'true'



// const sum = (a) =>(b) => a+b
// const sum1 = (a,b) => a+b

// console.log(sum1(2,3));   // Outputs 5
// console.log(sum(2)(3));



// (function () {
//     try {
//         throw new Error();
//     } catch (x) {
//         var x = 1, y = 2;
//         console.log(x);
//     }
//     console.log(x);
//     console.log(y);
// })();



// (function(x) {
//     return (function(y) {
//         console.log(x);
//         var x
//     })(2)
// })(1);



// var a={},
//     b={key:'b'},
//     c={key:'c'};

//     console.log(a[b])
// a[b]=456;
// a[c]=123;

// console.log(a[b]);

// b=123
// let a  = undefined + ''
// console.log(a,b)

// console.log(String(Symbol(1)))
// let sym = Symbol(123)
// console.log(sym)

// let a = 123 + []
// console.log(a, typeof a)
 

// let b = 3 ** 2
// let c  = 3 ** 9
// let a = 2 ** 8


// console.log(a,b,c)




// let arr3 = arr.forEach((ele,index) => {
//     let a = ele + 1
//     console.log(a)
//     return a
// })

// console.log(arr,arr3)

// let a1
// let arr2 = arr.map((ele) =>{
//     return  a1 = ele + 1
// })

// let arr = [2,22,2,13,2,1,3,1,3,1,1,1,1]
// let val = arr.reduce((accum,elem,index) =>{

//     return (elem == 14 ? accum + 1:accum)
//     // total = accum + ele
//     // if(index == arr.length - 1)
//     // return total/arr.length
//     // else
//     // return total
// },0)

// console.log(val)



// let obj1 = {
//     name:"Shubham",
//     details:function () {
//         console.log(`The name of the person is ${this.name}`)
    
// }
// }

// let obj2 = {
//     name:'Akash'
// }


// Function.prototype.mybind = ()  => {
//     console.log(this)
//     return function (){
//      }
// }
// let abind = obj1.details.mybind(obj2)
// // let abind = obj1.details.bind(obj2)
// abind()



// const obj = {
//     simple() {
//         return this 
//     }
// }

// let a = obj.simple
// console.log(obj.simple() == window)
// console.log(a() == window)


// console.log(5e4) // 5 * 10
// console.log(5e+4)
// console.log(5e-1)  // 5 / 10 =0.5
// console.log(5e-2)   // 5 / 100 = 0.2
// console.log(0e-5) // 0 / 100000
// console.log(5e500)
// console.log(-5e50)




// var d = {};
// // …what is accomplished using the following code?s

// [ 'zebra', 'horse' ].forEach(function(k) {
//     console.log(k)
//     d[k] = undefined;
//     console.log(d)
// })


// var d = {};
// // …what is accomplished using the following code?s

// [ 'zebra', 'horse' ].forEach(function(k) {
//     console.log(k)
//     d[k] = 24;
//     console.log(d)
// })



// let v = "0 || 1 = " + (2 || 3);
// console.log(v)



// let arr1 = ['apple','mango','grapes','orange','papaya']


// // arr1.length = 0 
// // console.log(arr1)
// let len = arr1.length
// console.log(len)

// console.log(arr1.splice(0,len))
// console.log(arr1)




//  let sum = (a) => (b) => a + b
// let total = sum(3,2)
// console.log(total)

// function sum(x) {
    
//             return function(y) { 
//                 return function(z){return x + y + z};
             
        
//     }}



// function sum(x) {
//     if (arguments.length == 2) {
//       return arguments[0] + arguments[1];
//     } else {
//       return function(y) { return x + y; };
//     }
//   }
//   console.log(sum(2,3));   // Outputs 5
//   console.log(sum(3)(3)(3));


// var list = readHugeList();

// var nextListItem = function() {
//     var item = list.pop();

//     if (item) {
//         // process the list item...
//         nextListItem();
//     }
// };

// let obj = { 
//     name:'Shubham',
//     age:34
// }
//  for (let k in obj){
//      console.log(obj[k])
//  }





// var a={},
//     b={key:'b'},
//     c={key:'c'};

// a[b]=123;
// a[c]=456;

// console.log(c['key']);
// console.log(b)

// console.log(a[b])




//  for b                   for c
// a['[object Object]']  =  a[ '[object object]' ]

// const  debounce = (fn,delay)  => {
//     let Timeid;
//     // console.log(delay)
//     return function(...args) {
     
//         if(Timeid) {
//             clearTimeout(Timeid)
//             // console.log('Clearing ')
//         }
//        Timeid = setTimeout(() =>{
//             fn(...args);
//         },delay);
//     }
// }
// document.getElementById('mybtn').addEventListener('click',debounce((e) => {

//     console.log("Clicked")
// },5000))

// PolyFill of Bind Method

// let basic = {
//     'name': 'shyam',
//     'age': 24,
//     callMe :function (city) {
//         // console.log(arguments)
//         console.log('Hi! my name is ' + this.name + ' and my age is ' + this.age + ' and my city is ' + arguments[0] + ' and state is ' + arguments[1]);
//       }
//   };
  
//   basic1 = {
//     'name': 'shubham',
//     'age': 25,   
//   }

//   Function.prototype.mybind = function (context, ...args1) {
//     let fn = this;
//     // console.log(this)
//     // console.log(context)

//     return function (...arg2) {
//         console.log(arguments)
//         fn.apply(context, [...args1, ...arg2])
//     }
//   };
// //   let callBinded = basic.callMe.bind(basic1, 'jammu');
//   let mycallBinded = basic.callMe.mybind(basic1, 'jammu');
// //   callBinded('j&k')
//   mycallBinded('j&k');



// let fruits = [
//     { name: 'Mango', price: 200},
//     { name: 'Apple', price: 300},
//     { name: 'Banana', price: 100},
//     { name: 'Grapes', price: 150}
//   ]


// Array.prototype.customFilter = function(callback, context){
//     var arr = [];
//     console.log(callback)
//         // console.log(12)
//     console.log(this)
//     for(i=0; i< this.length; i++){
//         // console.log(context)
//         if(callback.call(context,this[i], i, this)){
//             arr.push(this[i])
//         }
//     }
// //     console.log(arr)
//     return arr
// }

// fruits.customFilter(function(element){
//     if(element.price > 100){
//         console.log(element)
//     }
// })

// "use strict"
// var x=5,y=1
// var obj ={ x:10,y:15} 
// //  console.log(y)
// with(obj)  
// {  
//       alert(y)  
// }  

// var grade='C';  
// var result,grade;  
// switch(grade)  
// {  
// case'A':  
// {  
//         result+="10";  
// break;  
// }  
// case'B':  
// {  
//         result+=" 9";  
// break;  
// }  
// case'C':  
// {  
//         result+="8";    // result = result + 8
//                         // result = undefined + "8" = "undefined 8"
// break;  
// }  
// default:  
//     result+=" 0";  
// }  
// // document.write(result); 
// console.log(result)


// var grade='Z';  
// var result;  
// switch(grade)  
// {  
// case'A':  
//         result+="10";  
// case'B':  
//         result+=" 9";  
// case'C':  
//         result+=" 8";  
// default:  
//         result+=" 0";  
// }  
// document.write(result, typeof(result))
























// console.log(Number(NaN))


// for (var i = 0; i < 5; i++) {
//         setTimeout(function() { console.log(i); }, i * 1000 );
//       }



//       const arr = [10, 12, 15, 21];
// for (var i = 0; i < arr.length; i++) {
//   setTimeout(function() {
//     console.log('Index: ' + i + ', element: ' + arr[i]);
//   }, 3000);
// }



// const arr = [10, 12, 15, 21];
// for (var i = 0; i < arr.length; i++) {
//   setTimeout((function() {
//     console.log('Index: ' + i + ', element: ' + arr[i]);
//   })(i), 3000);
// }



// var b = [undefined];
// b[2] = 1;
// console.log(b);             // (3) [undefined, empty × 1, 1]
// console.log(b.map(e => 7)); // (3) [7,         empty × 1, 7]




// var length = 10;
// var name = 'dhgdh'
// function fn() {
//         console.log(this.name);
// 	console.log(this.length);
// }

// var obj = {
//   length: 5,
//  name :'dhgwwdh',
//   method: function(fn) {
//     fn();
//     arguments[0]();
//   }
// };

// obj.method(fn, 1,"gjhkk");



// var list = readHugeList();

// var nextListItem = function() {
//     var item = list.pop();

//     if (item) {
//         // process the list item...
//         nextListItem();
//     }
// };








// const obj1 = {
//     name:'Shubham',
//     age:24,
//     address:"Saibaba Nagar near Shanti Nagar Nagpur-02"
// }

// obj1.name = "Rohit Sharma"
// obj1.age = 674

// console.log(obj1)
//---------------------------------------------------------------------------
import React from 'react'
import {TouchableWithoutFeedback,Alert,Keyboard} from 'react-native'

// StartGameScreen Component
const StartGameScreen = props =>{
    const [enteredValue,setenteredValue] = useState('')
const [confirmed, setconfirmed] = useState(false)
const [selecetedNumber, setselectedNumber] = useState()


const resetInputHandler = () =>{
    setenteredValue('')
    setconfirmed(false)

}
    

const confirmInputHandler = () => {
    let chosenNumber = parseInt(enteredValue)
    if(isNaN(chosenNumber)|| chosenNumber <= 0 || chosenNumber > 99)
    {
        Alert.alert('Invalid Number','Number should be betwwen 1 to 99',[{text:'Okay',style:'destructive',onPress:resetInputHandler}])
    }
setconfirmed(true)
 setenteredValue('')
 setselectedNumber(chosenNumber)
 Keyboard.dismiss()

}

 let confirmedOutput 
 if(confirmed) 
 {
    confirmedOutput= <Card style={style.summaryContainer}>
        <Text>Your selected</Text>
        <NumberContainer>{selecetedNumber}</NumberContainer>
        <Button title="START GAME"/>
        </Card>
 }
return(<TouchableWithoutFeedback onPress={() =>{
    Keyboard.dismiss()}}>

        {confirmedOutput}
    </TouchableWithoutFeedback>
) }


const style = Stylesheet.create({
    summaryContainer:{
        marginTop:20,
        alignItems:'center'

    }
})

//--------------------------------------------------------------
// Conatiner -- NumberContainer

import React from 'react'
import {View,Stylesheet,Text} from 'react-native'
// import Colors


const NumberContainer = props => {
    return(
        <View style={style.Container}>
            <Text style={style.number}>{props.children}</Text>
        </View>
    )
}

export default NumberContainer

const style  = Stylesheet.create({
    Container:{
        borderWidth:2,
        borderColor:Colors.accent,
        padding:10,
        borderRadius:10,
        marginVertical:10,
        alignItems:'center',
        jsutifyContent:'center'

    },
    number:{
        color:Colors.accent,
        fontSize:20
    }
})
// ------------------------------------------------------------------------------
//Card Custom Component
//-------------------------------------------------------------

// GameScreen

import React from 'react'
import {Text,View,Stylesheet} from 'react-native'

const generateRandomBetween = (min,max,exclude) => {
    let min = Math.ceil(min)
    let max = Math.floor(max)
    let rndNum = Math.floor(Math.random() * (max-min)) + min 
    if(rndNum === exclude ) 
    {
        return generateRandomBetween(min,max,exclude)
    }
    
    else {
        return rndNum
    }
}
const GameScreen = props => {
    const [currentGuess,setcurrentGuess] = useState(generateRandomBetween(1,100,props.userChoice))
    return ()
}

export default GameScreen

const style = Stylesheet.create({

})



// ------------------------------------------------------------------------

// GameScreen Component 

// Stylesheet object

buttonContainer:{
    marginTop:Dimension.get('window').height > 600 ? 20 :5
}

listContainer : {
    width:Dimension.get('window').width > 350 ? '60%' :'80%'

}
// so we can use Dimesions object in this way also by putting some condition
// we can use use it anywhere in your component where there is Javascript is used.
// Like with the if checks we can also do it like if particular condition is true 
// then render the one style else render other style on the component

// gamescreenover

imageContainer :{
    width:Dimension.get("window").width * 0.7,
    height:Dimension.get("window").width * 0.7,
    marginVertical:Dimension.get("window").height / 30
}


resultContainer : {
    marginVertical:Dimension.get("window").height / 60
}


resultText :{
    fontSize:Dimension.get("window").height < 400 ? 16 : 20
}

// app.json 
orientation:'default'


// In portrait mode if you want that ur input doesnot overlay with you keyborad 
// You can make use of KeyBoardAvoidView which basically provide ur input a position or padding or height 
// so that it cannnot overlay ur input.
// if you want the scrolling view you should go for ScrollView or Flatlits

// // Start GameScreen 

// now to avoid scrolling issue we first wraps the return with ScrollView and to 
// avoid the overlay issue of keyborad on the input we use KeyBoardAvoidView
// and this should always be wrapped in ScrollView component 

<ScrollView>                            amount the pixel it slides up
    <KeyboardAvoidingView behaviour="position" keyboardVerticalOffset={30}>
        ....content
    </KeyboardAvoidingView>

</ScrollView>
//_______________________________________________________________________________


// MealItem.js -- component folder
import React from 'react'
import {View,Text,Stylesheet,TouchableOpacity, ImageBackground} from 'react-native'



const  MealItem = props =>{
    return(
        <View style={style.mealItem}> 
        <TouchableOpacity onPress={props.onSelectMeal}>
            <View>           // Categorymealscreen renderitem method
                <View style={{...style.mealRow,...style.mealHeader}}>
                <ImageBackground source={{uri:props.image}} style={style.bgImage} >
                    <View style={style.titlecontainer}>
                <Text style={style.title} numberOfLines={1}> {props.title}</Text> 
                </View>
                {/* Apply style on text as it is not claerly visible 
                and Imagebackground acts as a Flex box so it can be used to 
                orientatet it's  child component/elements*/}
                </ImageBackground>
                </View>
                <View style={{...style.mealRow,...style.mealDetail}}>
                    <Text>{props.duration}</Text>
                    <Text>{props.complexity}</Text>
                    <Text>{props.affordability}</Text>
                </View>
            </View>
        </TouchableOpacity>
        </View>
    )
}

const style = Stylesheet.create({
    mealItem:{
        height:200,
        width:'100%',
        backgroundColor:'#f5f5f5',
        borderRadius:10,
        overflow:'hidden'


    },
    bgImage:{
        width:'100%',
        height:'100%',
        justifyContent:'flex-end'
    },
    mealRow:{
        flexdirection:'row'
    },
    mealHeader:
    {
        header:'90%'
    },
    mealDetail:{
        paddingHorizontal:10,
        justifyContent:'space-between',
        alignItems:'center',
        height:'15%'
    },
    titlecontainer:{
        backgroundColor:rgba(0,0,0,0.5),
        paddingVertical:5,
        paddingHorizontal:12,
    },
    title:{
        fontFamily:'open-sans-bold',
        fontSize:20,
        color:'white',
        // backgroundColor:rgba(0,0,0,0.5),
        // paddingVertical:5,
        // paddingHorizontal:12,
        textAlign:'center'
    }
})

export default MealItem
//------
//CategoryMealScreen

const renderItemMeal = itemData => {
    return <MealItem title={itemData.item.title} 
     image={itemData.item.imageUrl}
     duration={itemData.item.duration} 
     complexity={itemData.item.complexity.toUpperCase()}
     affordability={itemData.item.affordability.toUpperCase()}
     onSelectMeal={()=>{
         props.navigation.navigate({routeName:'MealDetail',params:{
               mealId: itemData.item.id
         }})
     }}
     />
}

on FlatList add style property style={{width:'100%'}}  // so that the flatlist can take 100% width


// MealDetailScreen Component
import React from 'react'
import {View,Text,Stylesheet,Button} from 'react-native'
import {MEALS} from '../data/dummy-data'
import {HeaderButtons,Item} from 'react-navigation-header-buttons'
import HeaderButton from '../component/HeaderButton'

const MealDetailScreen = props => {
    const mealId =  props.navigation.getParam('mealId')

    const selectedMeal = MEALS.filter(meal => meal.id === mealId)

    return (
        <View>
            <Text>{selectedMeal.title}</Text>
            <Button title="Go Back to Categories" onPress={() => {
                props.navigation.popToTop();
            }}/>
        </View>
    )
}

MealDetailScreen.navigationOptions = navigationData => {
    const mealId =  navigationData.navigation.getParam('mealId')

    const selectedMeal = MEALS.filter(meal => meal.id === mealId)

    return{
        headerTitle : selectedMeal.title,
        // headerRight: <Text>FAV!</Text>  //(Can you JSX component here)
        headerRight:<HeaderButtons HeaderButtonComponent={HeaderButton}>
            <Item title='Favourite' iconName="ios-start"  onPress={() => {
                console.log('Mark is favourite')

                // We can use mutliple Icons to render on the Header
                // if it is we should make title unique as it works as a key
                // title :-  used as a fallback but title for the item which we cannot see
                //iconName : name of the icons that you want to render as item from (Ionicons)
                // expo vector icons ... and it should be name of the Ionicons...
            }} />
            {/* <Item title='Favourite' iconName="ios-start-outline"  onPress={() => {
                console.log('Mark is favourite')

                // We can use mutliple Icons to render on the Header
                // if it is we should make title unique as it works as a key
                // title :-  used as a fallback but title for the item which we cannot see
                //iconName : name of the icons that you want to render as item from (Ionicons)
                // expo vector icons ... and it should be name of the Ionicons...
            }} /> */}

            

            
        </HeaderButtons>
    }
}


// Need to install the below package npm install react-naivgation-header-button
// Although you can add button simply but using headerRight or headerLeft.
// Mostly headerLeft is reserved for back button so we mostly use headerRight but it 
// very cumbersome we can just text component(Can use JSX here ... component)
// but usually used ICons and to manage it style it and oriented in diff platform 
// is little bit complex if we managed it youselvews but this package made it easier for us


// components/HeaderButton

import React from 'react'
import {Platform} from 'react-native'
import {HeaderButton}  from 'react-navigation-header-buttons'
import Colors from '../constants/Colors'
import {Ionicons} from '@expo/vector-icons'


const CustomHeaderButton = props => {
    return (
        <HeaderButton {...props}
        IconComponent={Ionicons}
        iconSize={23}
        color={Platform.OS === 'android' ? 'white' : Colors.primary}
        />
    )
}


export default CustomHeaderButton


import {createBottomTabNavigator}  from 'react-navigation-tabs'
import {Iconicons} from '@expo/vector-icons'


const  MealFavTabNavigator = createBottomTabNavigator({
    Meals:{screen:MealsNavigator,
        navigationOptions:{
            // this tabInfo provides us all the tab conf i.e color etc
            // and returns an Icon that need to be rendered
            tabBarIcon:(tabInfo) =>{
                return <Iconicons  name='ios-restaurant' size={25} color={tabInfo.tintColor}/>
            }
        }},
    Favorites:{screen: FavoritesScreen,
        navigationOptions:{
            // tabBarLabel:'Favourites!!',
            tabBarIcon:(tabInfo) =>{
                return <Iconicons  name='ios-star' size={25} color={tabInfo.tintColor}/>
            }
        }
    }
},{
    tabBarOptions:{
        activeTintColor:Colors.accentColor
    }
})

export default createAppContainer(MealFavTabNavigator)


// Redux Module : 

// Meals Reducer 

const initialState = {
    meal:MEALS,
    favoriteScreen:MEALS,
    filteredScreen:[]
}

const mealReducer = (state=initialState,action) => {
    return state
}

export default mealReducer

// App Component

import {createStore,combineReducers} from 'redux'
import {Provider} from 'react-redux'
import mealsReducer from './store/reducers/meals'

const rootReducer = combineReducers({

meals:mealsReducer
})
const store = createStore(rootReducer)

const App = () => {
    return(
        <Provider store={store}> <MealsNavigator /></Provider>
        
    )
}
//-------------
// CategoryMealScreen
import {useSelector} from 'react-redux'

const CategoryMealScreen = props => {

    const avaliableMeals = useSelector(state => state.meals.filteredMeals)

    const displayedMeals = avaliableMeals.filter(meals => meals.categoryIds.indexOf(catId) >= 0)
}

// FavoritesScreen
import {useSelector} from 'react-redux'

const favMeals = useSelector(state => state.meals.favoriteMeals)
return (
    <MealList listData={favMeals} navigation={props.navigation} />
)

// MealDetailScreen
import {useSelector} from 'react-redux'

const avaliableMeals = useSelector(state => state.meals.meals)
const mealId = props.navigation.getParam('mealId')
const selectedMeal = avaliableMeals.find(meal => meal.id === mealId)


// Now in the navigationOptions that we are using Meals but now we are 
// using redux but the Hook Selector Hook is not available so we need 
// find an alternative to find connection between your navigationOptions and Redux

// These can be done in 2 ways


// MealDetailScreen
import {useSelector,useDispatch} from 'react-redux'
import {toggleFavorite} from '../store/actions/meals'

const avaliableMeals = useSelector(state => state.meals.meals)
const mealId = props.navigation.getParam('mealId')
const selectedMeal = avaliableMeals.find(meal => meal.id === mealId)
  
const dispatch = useDispatch()
const toggleFavoriteHandler = useCallback(() => {
    dispatch(toggleFavorite(mealId))
},[dispatch,mealId])

useEffect(() => {
    // props.navigation.setParams({mealTitle:selectedMeal.title})
    props.naviagtion.setParams({toggleFav:toggleFavoriteHandler})
    
}, [toggleFavoriteHandler])

MealDetailScreen.navigationOptions = navigationData => {
    // const mealId =  navigationData.navigation.getParam('mealId')
    const toggleFavorite = navigationData.navigation.getParam('toggleFav')
    const mealTitle =  navigationData.navigation.getParam('mealTitle')
    // const selectedMeal = MEALS.filter(meal => meal.id === mealId)

    return{
        // headerTitle : selectedMeal.title,
        headerTitle : mealTitle,
        // headerRight: <Text>FAV!</Text>  //(Can you JSX component here)
        headerRight:<HeaderButtons HeaderButtonComponent={HeaderButton}>
                        <Item title='Favourite' iconName="ios-start"  onPress={toggleFavorite} />
                </HeaderButtons>

            }
        }
// 1 with this line we can merge the properties in Params and we have the 
// access of navigationOptions.so we can make use of it.But it continosuly changing the
// props hence it will goes in infinite loop so we useEffect. but as first useeffect runs 
// after the render method once the page loaded then only headertitle is updated.
 // 2 Secondly we can the title propertes  as a Params on the Component it gets called


// In MealList component

// pass the value as Params 
params:{
    mealId:itemData.item.id,
    mealTitle:itemData.item.title
}



// Store/action/meals.js

export const TOGGLE_FAVORITE = 'TOGGLE_FAVORITE'

export const toggleFavorite = id =>{
    return{
        type:TOGGLE_FAVORITE,
        mealId:id
    }
}



// store/reducer/mealReducer

const initialState = {
    meal:MEALS,
    favoriteMeals:[],
    filteredMeals:MEALS
}

const mealReducer = (state=initialState,action) => {
    switch(action.type) {
        case TOGGLE_FAVORITE:
            const exisitngIndex = state.favoriteMeals.findIndex(
                meal => meal.id === action.mealId)
               if(exisitngIndex >= 0)
               {
                   const updatedFavMeals = [...favoriteMeals]
                   updatedFavMeals.splice(exisitngIndex,1)
                   return {...state,favoriteMeals:updatedFavMeals}
               }
            else {
                const meal = state.meal.find(meal => meal.id === action.mealId)
                return{...state,favoriteMeals:state.favoriteMeals.concat(meal)}
            }
            default:
                return state
    }
    
}

export default mealReducer






















