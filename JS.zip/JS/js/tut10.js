console.log(" We r now in tut10");

// const mygreet = function (name,thanks="thanks you")
// {
//     console.log(`Happy Birthday ${name} May god bless you with whatever you want ${thanks}`)
//     return name;
// }
 
// name = 'Shubham';
// let v = mygreet(name)
// console.log(v);


// let myobj = {
//     name: "Rohan",
//     game: function(){
//         return "GTA"
//     }


// }
// console.log(myobj.game());

// arr = ['fruits','vegetable','furniture'];

// arr.forEach(function (element,index,array ){
//     console.log(element,index);
    
// });





