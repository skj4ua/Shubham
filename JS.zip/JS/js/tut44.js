console.log("We are in now tut44");
// explicity thorwing the custom  error message
let a = "Hello Harry!!"
// a = undefined
// if(a!=undefined)
// {   
//      throw new Error ("This is not undefined");
// }
// else
// {
//     console.log("This is  undefined");
// }


try {
    // sjlakakjdkjkdj
    // Harry();
    // let a = null;
    // console.log(a);
    null.console;
    console.log("We are now in try block");
} catch (error) {
    console.log("We are now in catch  block");  
    console.log(error.name); 
    console.log(error.message); 
}finally{
    console.log("Finally we run this")
}

// Unless try or catch runs or not finally will always excute