console.log("This is tut31");

class Employee{
    constructor(givenName,givenExperience,givenDivison){
        this.name = givenName;
        this.experience = givenExperience;
        this.division = givenDivison;
    }
    slogan()
    {
        return `I am ${this.name} and my company is awesome`
    }

    JoiningYear()
    {
        return 2020-this.experience;
    }

    static add(a,b)
    {
        return a*b;
    }
}

a = new Employee("Shubham",2,"Finacial Services");
console.log(Employee.add(5,4));

class Programmer extends Employee{
    constructor(givenName,givenExperience,givenDivison,language,github)
    {
        super(givenName,givenExperience,givenDivison);
        this.language = language;
        this.github = github;
    }
    favouriteLanguage(){
        if(this.language == "Pyhton")
        return "Python"
        else
        return "Java Script"
    }
    static mul(a,b)
    {
        return (a*b)
    }
}

b = new Programmer("Rohan",3,"Cards and Payments","MongoDB","Rohan240");
console.log(b.favouriteLanguage());