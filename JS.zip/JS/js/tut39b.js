console.log("We are in tut 37");

const students = [
    {name:"Harry",subject:"Javascript"},
    {name: "Rohan",subject:"Machine learning"}
]

function enrollStudent(student)
{
    return new Promise(function(resolve,reject)
    {
   setTimeout(function() {
      students.push(student);  
      console.log("student has been enrolled")
    //   callback();
    error = false;
    if(!error)
    {
        resolve();
    }
    else 
    {
         reject();
    }
    }, 3000);
})
}

function getStudent(){
    setTimeout(() => {
        str = '';

        students.forEach(function(element) {
            // console.log(element.name);
            str += `<li>${element.name}</li>`
            
        });
         document.getElementById('list').innerHTML = str
         console.log("student has been fetched")
    }, 1000);
}

let newStudent = {name:"Shubham",subject:"JS"};
enrollStudent(newStudent).then(function(){
    getStudent()
}).catch(function(){
    console.log("Not poosible to fetch the canditaure details")
})
// getStudent();

