console.log("Ajax tutorial in one video");


// let fetchBtn = document.getElementById("fetchBtn");
// fetchBtn.addEventListener('click', butttonClickHandler)
// function butttonClickHandler() {
//     //Instantiate an xhr object
//     const xhr = new XMLHttpRequest();

//     //open the object 

//     // xhr.open('GET', 'harry.txt', true);
//     // xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1', true);
//     xhr.open('GET','tut1.json', true);


//     //what to do on progress(optional)  loader or spinners
//     xhr.onprogress = function () {
//         console.log("On progress");
//     }
//     // Value	State	Description
//     // 0	    UNSENT	Client has been created. open() not called yet.
//     // 1	    OPENED	open() has been called.
//     // 2	    HEADERS_RECEIVED	send() has been called, and headers and status are available.
//     // 3	    LOADING	Downloading; responseText holds partial data.
//     // 4	    DONE	The operation is complete.

//     // xhr.onreadystatechange = function()
//     // {
//     //     console.log("the ready state is ", xhr.readyState);
//     // }


//     // What to do when response is ready

//     xhr.onload = function()
//     {   // Http status codes 200 --> ok  404 --> Path Not found
//          if(this.status == 200)
//         console.log(this.responseText);
//         else
//         console.log("some error occured");
//     }

//     xhr.send();
//     console.log("We are done");

// }
let backupBtn = document.getElementById("backupBtn");
backupBtn.addEventListener('click', butttonClickHandler)
function butttonClickHandler() {
    //Instantiate an xhr object
    const xhr = new XMLHttpRequest();

    //open the object 

    // xhr.open('GET', 'harry.txt', true);
    // xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1', true);
    xhr.open('GET', 'http://dummy.restapiexample.com/api/v1/employees', true);


    //what to do on progress(optional)  loader or spinners
    // xhr.onprogress = function () {
    //     console.log("On progress");
    // }
    // Value	State	Description
    // 0	    UNSENT	Client has been created. open() not called yet.
    // 1	    OPENED	open() has been called.
    // 2	    HEADERS_RECEIVED	send() has been called, and headers and status are available.
    // 3	    LOADING	Downloading; responseText holds partial data.
    // 4	    DONE	The operation is complete.

    // xhr.onreadystatechange = function()
    // {
    //     console.log("the ready state is ", xhr.readyState);
    // }


    // What to do when response is ready

    xhr.onload = function () {   // Http status codes 200 --> ok  404 --> Path Not found
        if (this.status == 200) {
            // console.log(this.responseText);

            let obj = JSON.parse(this.responseText);
            // myobj = obj.splice(0,1);
             console.log(obj);
                myobj = obj['data'];
                console.log(myobj);
            let html = "";
            let a = document.getElementById("first");
            // console.log(a);
            // if (obj[0] != "success")
            for (key in myobj) {
                 
                    // console.log(key);
                    // for(p in obj)
                //    console.log(obj[key]);
                    html += `<li>${myobj[key].employee_name}</li>`
                    
                }
                
            

            a.innerHTML = html;
        }

        else
            console.log("some error occured");
    }

    xhr.send();
    console.log("We are done");

}