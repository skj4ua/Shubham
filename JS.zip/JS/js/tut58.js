console.log("We are tutorial 58");
let myArray = [1,1,1,1,1,4,3,3,4,4,56,54]
// Set are used to have the unique values

// let mySet = new Set(["Hello","Good Morning",527,false]);
let mySet = new Set(myArray);
console.log(mySet);
// mySet.add("Hello");
// mySet.add("Good Morning");
// mySet.add("Hello") it takes the unique values only in the set
// mySet.add(537);
// mySet.add(true);
// console.log("Before removal" ,mySet);
// console.log(mySet.has("Hello"));
// // console.log(mySet.size);
// mySet.delete("Hello");
// console.log(mySet.has("Hello"));
// console.log("After removal",mySet);

// As we print the Myset first and then again after the delete
// then if we try to view the element deleted in first print it is not shown as it updated one.

// console.log(Array.from(mySet));

// console.log(mySet.has("Hello"));
// console.log(mySet.has("Hello"));



// Iterating the set

// for(item of mySet)
// {
//     console.log(item)
// }


// mySet.forEach((item)=>{
//     console.log(item);
// })