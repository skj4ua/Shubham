console.log("Welcome to tut 36");

class Library{
    constructor(booklist)
    {
        this.booklist = booklist;
        this.issuedBook = {};
    }

    getbooklist(){
        this.booklist.forEach(element => {
            console.log(element);
        });
    }

    IssueBook(bookName,user)
    {
        console.log(this.issuedBook[bookName])
        if(this.issuedBook[bookName] == undefined)
        {
        this.issuedBook[bookName] = user;
        console.log(this.issuedBook[bookName]);
        }
        else
        {
            console.log(" This book is already issue");
        }

       }
       returnBook(bookName)
        {
          delete this.issuedBook[bookName]
        }

    }



