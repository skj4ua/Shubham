console.log("Hii!!!!");
let a = document.createElement('a');
a.href = "https://www.google.com/";
a.title = "mytitle";

let elem = document.createElement('h3');
elem.className = 'childq';
elem.id = 'bh';
elem.innerHTML = 'hjdkfk',
console.log(elem);
elem.appendChild(a);
document.body.appendChild(elem);

