console.log("We are now doing clock project");

function UpdateClock()
{
    let currentDate = new Date();
    // console.log(currentDate);
    let currentHour = currentDate.getHours();
    let currentMinutes = currentDate.getMinutes();
    let currentSeconds = currentDate.getSeconds();

    currentMinutes = (currentMinutes < 10 ? "0" : "") + currentMinutes;
    currentSeconds = (currentSeconds < 10 ? "0" : "") + currentSeconds;

    currentHour = (currentHour > 12 ? currentHour-12 : currentHour);
    currentHour = (currentHour == 0 ? 12 : currentHour)
    let Daytime = (currentHour < 12) ? "AM" : "PM";

    currentTimeStr  = currentHour + ":" + currentMinutes + ":" 
                        + currentSeconds + " " + Daytime;

    let clock = document.getElementById("clock");
    clock.innerHTML = currentTimeStr

}