// console.log('Index.js')
let a = require('./mod')
let average = a.avg([1,2])
console.log("The sum of two no is " + average)
console.log("The name of the user is " + a.name)
console.log("The id of the user is " + a.id)

