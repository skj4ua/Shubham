console.log('Mode.js!!!')

const average = (arr) =>{
    let sum = 0;
    arr.forEach(element => {
        sum = sum + element
        
    });
    return sum
}

module.exports =  {
    avg: average,
    name:"Shubham",
    id:'101',
    current_company:"capgemini"
}
