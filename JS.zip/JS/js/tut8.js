console.log("we are in now tut 8");
const Age =  28;
let vari = 34;
const drive = false;
// if(Age!=93){
//     console.log("Age is not 93")
// }
// if(Age===33){
//     console.log('Age is 33')
// }
// // === check value and type
// // == check only value

// else{
//     console.log("Age is not 23")
// }

// if(typeof vari !== 'undefined'){
//     console.log('vari is defined');
// }
// else{
//     console.log('vari is not defined');
// }
//  if(drive && Age>18){
//      console.log("You can drive");
//  }
// else{
//     console.log("You cannot drive");
// }

// ternary opertaor

// console.log(drive==true? "You can drive":"You cannot drive");

// Switch case statement
switch (Age) {
    case 18:
        console.log("You age is 18");
        break;
     case 28:
        console.log("You age is 28");
        break;
    case 38:
        console.log("You age is 38");
        break;   
    default:
        console.log("You age is unknown")
        break;
}
