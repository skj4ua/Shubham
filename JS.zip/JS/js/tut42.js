console.log("This is tut42");
let mybtn = document.getElementById("mybtn");

// function getData(){
//     let url ="harry.txt"
//     fetch(url).then(function(resolve){
//         return (resolve.text())
//     }).then(function(data){
//         console.log(data)
//     })
// }


// function getData(){
//     let url ="https://api.github.com/users/diego3g "
//     fetch(url).then(function(resolve){
//         return (resolve.json())
//     }).then(function(data){
//         console.log(data)
//     })
// }


function getData(){
    let url ="http://dummy.restapiexample.com/api/v1/create"
    data = '{"name":"harrrttguj","salary":"123","age":"23"}'
    params = {
        method:'post',

        header: {
            'Content-Type':'application/json'
        },
        body:data
    }
    
    fetch(url,params).then(function(resolve){
        return (resolve.json())
    }).then(function(data){
        console.log(data)
    })
}
getData();

