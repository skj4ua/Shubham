console.log('We are in tut14 now');


// Single element Selector

let element = document.getElementById('first');

//element = element.className;
//element = element.parentNode;
// element = element.childNodes;


 element.style.color ='red';
// element.style.background = 'green'
 element.innerText = "Shubham is good boy"
// element.style.width = '500'
 element.innerHTML = '<b>Shubham is good boy</b>'

// console.log(element.innerText)
// console.log(element.innerHTML)

let sel = document.querySelector('#first');
sel = document.querySelector('.child')
sel = document.querySelector('b')
sel = document.querySelector('div');

sel.style.color = 'green';
// console.log(sel);



// Multi Element Selector

let elems  = document.getElementsByClassName('child');
elems = document.getElementsByClassName('container')

// console.log(elems[0].getElementsByClassName('child'));

elems  = document.getElementsByTagName('div');



Array.from(elems).forEach(function(element) {
    element.style.color = 'red';
    console.log(element);
});







 



