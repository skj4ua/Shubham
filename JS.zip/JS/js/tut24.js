console.log("Welcome to tut24");
let today  = new Date();
// console.log(today);
let otherDate = new Date('2-8-2019 06:33:26');
// otherDate = new Date('June 23 2020');
// otherDate = new Date('03/09/2020')
console.log(otherDate);

//MMDDYY format is valid if you give DDMMYY then it is invalid ...

let a;
// a = otherDate.getDate();
// a = otherDate.getDay();
// a = otherDate.getMinutes();
// a = otherDate.getSeconds();
// a = otherDate.getHours();
// a = otherDate.getTime(); timestmap no of sec sinec 01 JAN 1970
// a = otherDate.getMilliseconds();
// a = otherDate.getMonth();
// counting start with 0
// console.log(a);


//We can Set the paramater also

otherDate.setDate('20');
otherDate.setMonth('05');
otherDate.setFullYear('2020');
otherDate.setMinutes('01');
otherDate.setHours('06');
otherDate.setSeconds('23');
console.log(otherDate);
