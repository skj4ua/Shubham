console.log(" We are now in tut18");
// let btn = document.getElementById('btn');
// btn.addEventListener('click',func1);
// // btn.addEventListener('mousedown',func3);
// btn.addEventListener('dbclick',func2);
// function func1(e)
// {
//     console.log('Thanks',e);
//     e.preventDefault();
// }

// function func2(e)
// {
//     console.log('Thanks it is a double click',e);
//     e.preventDefault();
// }
// console.log(1)
// function func3(e)
// {
//     console.log('Thanks it is a mouse down',e);
//     e.preventDefault();
// }

// <!----> <input type="button" <!---> id='btn' value="Submit">

// if we use form and then use button tag or submit (input type) then clivking on it it directs us to none.html(form tag);


// document.querySelector('.non').addEventListener('mouseenter',function(){

//         console.log('you entered no')

// })

// document.querySelector('.non').addEventListener('mouseleave',function(){

//     console.log('you exited no')

// })

document.querySelector('.container').addEventListener('mousemove',function(e){
    // console.log(e.offsetX,e.offsetY);
    document.body.style.backgroundColor = `rgb(${e.offsetX},${e.offsetY},${e.offsetY},198)`;
    console.log('you have triggered mouse event')

})

