console.log("Welcome to tut25");
let divElem = document.createElement("div");
let ls = localStorage.getItem("ls");
let text;
if(ls == null)
{
 text  = document.createTextNode("Hello!!! Good Morning");}
else{
 text = document.createTextNode(ls);
}
divElem.setAttribute('id','elem');
divElem.setAttribute('class','elem');
divElem.setAttribute('style','border:5px solid black;width:154px;margin:34px;padding:23px');
divElem.appendChild(text);
let container = document.querySelector('.container');
let first = document.getElementById('first');
container.insertBefore(divElem,first);

divElem.addEventListener('click',function()
{
  let notextArea = document.getElementsByClassName('textArea').length;
  if(notextArea == 0){
  let html = divElem.innerHTML;
  divElem.innerHTML =`<textarea class=" textArea form-control" id="textArea" rows="3">${html}</textarea>`
  }
  let textarea = document.getElementById('textArea');
  textarea.addEventListener('blur',function(){
    elem.innerHTML = textarea.value;
    localStorage.setItem("ls",textarea.value);
  })
})


