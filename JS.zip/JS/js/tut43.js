console.log("welcome to tut43");

async function Harry()
{ url="https://api.github.com/users";

let response = await fetch(url);
let data = await response.json();
return(data)

}

let a = Harry();
console.log(a);
a.then(function(data){ console.log(data)
});




