console.log('Hello JS')
console.log(24)