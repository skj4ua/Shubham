console.log("welcome to tut30");
const proto = {
    slogan: function(){
        return "This company is the best";
    },
    changeName: function(newName){
        this.name = newName;
    }

}


// this creates harry object
const harry = Object.create(proto);
harry.name = "Harry";
harry.role = "Programmer";
// console.log(harry.slogan());
 
// this also creates the harry object
// const harry = Object.create(proto, {
//     name:{value:"harry",writable:true},
//     role:{value:"programmer"},
// });

// harry.changeName("Rohit")
//  console.log(harry);


// function Employee(name,salary,experience){
//     this.name = name;
//     this.salary = salary;
//     this.experience = experience
// }

// Employee.prototype.slogan = function(){
//     return "This company is the best Regards,${this.name}"
// }
// let harryobj = new Employee("shubham",28310,2);
// console.log(harryobj);
