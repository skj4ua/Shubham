console.log("We are now in tut12");
 //let a = document.all;
// let a = document.body;
// let a = document.forms;

// console.log(a) 

// Array.from(a).forEach(function(element) {
//     console.log(element)
    
// });
//  a = document.links[0].href;
a = document.images;
 console.log(a);