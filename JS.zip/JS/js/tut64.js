const fs = require('fs')
let text = fs.readFileSync('dele.txt','utf-8')
// console.log(text)
text = text.replace('CapGemini!!','AWS') 
console.log(text)

fs.writeFileSync('Shubham.txt',text)