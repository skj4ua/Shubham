console.log("Welcome to tutorial 23");
let x = 3;
let y = 6;
let z 
// console.log(z) //output will undefined
z = x+y;
z = x-y;
z = x*y;
z = x/y;


// Exploring the Math object
z = Math;
// z = Math.PI;
// z = Math.E;
// z = Math.round(5.5);
// z = Math.ceil(5.3);
// z = Math.floor(-5.3); 
// //floor will give output to it lowest value for e.g. 4.5 it will give 4 and for -4.5 it will give -5
z = Math.abs(-5);
z = Math.sqrt(64);
z = Math.pow(2,3);
z = Math.min(44,53,2,424,242,24);
z = Math.max(44,53,2,424,242,24);
z = Math.random();
// // above function generate random number between 0-1;
z = 100*Math.random();
// // above function generate random number between 0-100;
z = Math.ceil(50 + (100 - 50)*Math.random());
console.log(z)
//a =(0,1)
//a100 = a*100 = (0,100)
//a10_100 = 10 + a *(100-10)


