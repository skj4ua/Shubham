// console.log("Hello World")
const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  res.end(` <!DOCTYPE html>
  <html lang="en">
  
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Document</title>
      <style>
          .container {
              border:3px solid red;
              background-color: rgb(13, 228, 103);
              padding: 34px;
              margin: 34px auto;
              width: 666px;
          }
          a:hover{
              background-color: rgb(241, 245, 21);
          }
          a:visited
          {
              background-color:rgba(9, 9, 247, 0.877);
          }
          a:active{
              background-color: rgb(247, 14, 149);
          }
          .container a{
              text-decoration:none;
              color:black;
  
          }
          .btn{
              font-family: Arial, Helvetica, 
              sans-serif;
              font-weight: bolder;
              padding:6px;
              /* margin:3px; */
              background-color: red;
              border: none;
              cursor:pointer;
              font-size: 13px;
              border-radius: 5px;
  
          }
      </style>
  </head>
  
  <body>
      <div class="container">
          <h3>This is my heading</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae laudantium blanditiis aliquid similique
              quia vitae officiis, officia eaque. Repellendus amet commodi sint similique voluptates tempora, dicta saepe
              optio vel sed.</p>
              <a href="https://www.google.com/" class='btn'>Read More</a>
              <button class='btn'>Contact Us</button>
      </div>
  </body>
  
  </html>
  `);
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});