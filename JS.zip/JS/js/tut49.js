console.log(" We are in tutorial 49");
let regex = /\war/;          //word character - _ or alphabet or numbers
regex = /\w+0r/;            //\w+  means one or more word character
regex = /\Wbhai/;          // Non word character
regex = /\W+bhai/;        //\W+ means more than one or more Non word character
regex = /number \d999/   // \d means digit
regex = /number \d+/    // \d+ means one or more than one digit
regex = /\D899/        // \D means non digit
regex = /\D+999/      // \D+ means more than one non digit
regex = /\ska number/     //
regex = /\s+ka number/
regex = /\S ka number/
regex = /\S+  ka number/
regex = /\W+/

// Assertion 

// regex = /h(?=y)/;
// regex = /h(?!y)/

str = 'hdrhar0r1r2r %#^&&@bhai hyrry  ka number 89999harry9999'
let result = regex.exec(str);
console.log("result of exec is",result);

if(regex.test(str))
{
    console.log(`The string ${str} matches the expression ${regex.source}`)
}

else {
    console.log(`The string ${str}  does not  match the expression ${regex.source}`)
}