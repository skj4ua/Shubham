console.log("We are in tutorial 55");

let Mymap = new Map();

let key1 = "Hello" , key2 = {} , key3 = function(){};
Mymap.set(key1,"String is inside it");
Mymap.set(key2,"Is a empty literal");
Mymap.set(key3,"Is a empty function");
// console.log(Mymap);

let a  = Mymap.get(key1);
// console.log(a);
// console.log(Mymap.size)

for ([keys,values] of Mymap)
{
    // console.log("The keys are ", keys);
    // console.log("The values are", values);
}

for (keys of Mymap.keys())
{
    // console.log("The keys are ", keys);
     
}


for (values of Mymap.values())
{
    // console.log("The values are ", values);
     
}

let myArray = Array.from(Mymap);
  console.log(myArray);

  let myKeysArray = Array.from(Mymap.keys());
  console.log(myKeysArray);

  let myValuesArray = Array.from(Mymap.values());
  console.log(myValuesArray);


Mymap.forEach((values,keys)=>{
    // console.log("The keys are ", keys);
    // console.log("The value ", values + " is for the key",keys);

})

