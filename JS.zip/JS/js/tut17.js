console.log(" We are in now tut17");
document.getElementById("heading").
// mouseover is also an event
addEventListener("click", function (e) {
    console.log("You have click heading");
    //location.href = "https://www.google.com" 
    let variable = e.target;
    let c = e.target.className;
    c = e.target.classList;
    //    c = e.target.id
    c = e.offsetX;
    c = e.offsetY;
    c = e.clientX;
    c = e.clientY
    console.log(c);
    // let d = Array.from(c)
    // console.log(d);

});

