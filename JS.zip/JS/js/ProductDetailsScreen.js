import React from 'react'
import {Button,View,Text} from 'react-native'

return(
    <ScrollView>

        <Image source={{uri:selectedProduct.imageUrl}}/>
        <Button color={Colors.Primary} />
        <Text>{selectedProduct.price}</Text>
        <Text>{selectedProduct.discription}</Text>
    </ScrollView>
)
  

const style = StyleSheet.create({
    ImageContainer:{
        width:'100%',
        height:350
    },
    ButtonConatiner:{
        marginVertical:10,
        alignItems:'center'
    }

})
