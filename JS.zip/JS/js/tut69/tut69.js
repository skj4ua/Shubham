console.log("Hello")

let a = 10;

(func1 = ()=>{
    let a = 20;
    console.log("The value of a inside func1 " + a)
})()

// func1()

console.log("The value of a outside  func1 " + a)