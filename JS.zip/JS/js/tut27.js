console.log("We are now in tut27");
//  object literal for creating object
let car = {
    name:"Maruti Suzuki",
    topSpeed:800,
    run:function(){
        console.log("car is runnig")
        
    }
}
// console.log(car.name);
// console.log(car.topSpeed);
// console.log(car.run())

// We have already seen the constructor
// new Date();

// creating the constructor for Car
function GeneralCar(Givenname,speed)
{
    this.name = Givenname;
    this.topspeed = speed;
    this.run = function()
    {
        return(`the car ${this.name} is running at a speed of ${this.topSpeed}`)
    }
    this.analyse = function()
    {
        console.log(` ${this.name}KM/H is slower by ${200 - this.topspeed}KM/H than Mercedes`)
    }


}

let a1 = new GeneralCar("Alto 800",90);
let a2 =new GeneralCar("Maruti Alto", 80);
let a3 = new GeneralCar("Mercedes",200);
console.log(a1,a2,a3);


