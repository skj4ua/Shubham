console.log("We are in tut 37");

const students = [
    {name:"Harry",subject:"Javascript"},
    {name: "Rohan",subject:"Machine learning"}
]

function enrollStudent(student,callback)
{
    setTimeout(() => {
      students.push(student);  
      console.log("student has been enrolled")
      callback();
        
    }, 3000);
}

function getStudent(){
    setTimeout(() => {
        str = '';

        students.forEach(function(element) {
            // console.log(element.name);
            str += `<li>${element.name}</li>`
            
        });
         document.getElementById('list').innerHTML = str
         console.log("student has been fetched")
    }, 1000);
}

let newStudent = {name:"Shubham",subject:"JS"};
enrollStudent(newStudent,getStudent);
// getStudent();

