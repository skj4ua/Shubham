console.log("Welcome to tutorial 52");
// Generator is used to generate values on the high

function* Harry()
{
    let i = 0;

    // yield 1;
    // yield 2;
    // yield 3;
    // yield 4;

    while(true){
     
        //  yield (i++).toString();
        yield i++;

         
    }
}

let v  = Harry();
console.log(v.next().value);
console.log(v.next().value);  
console.log(v.next().value);   
console.log(v.next().value);
console.log(v.next().value);
 

