const express = require('express');
const app = express();
const port = 80;
app.get('/about',(req,res)=>{
    res.send("This is my first page ")
})

app.listen(port, ()=>{
    console.log(`the appliaction is start succesfully ${port}`)
})