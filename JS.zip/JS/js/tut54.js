console.log("We are in tutorial 54");

let addBtn  = document.getElementById("addBtn");
// console.log(addBtn);
addBtn.addEventListener("click",harry);
function harry(){

    let alarm = document.getElementById("alarm");
    let txtval = new Date(alarm.value);
    // console.log(txtval);
    let currtime = new Date();
    // console.log(currtime);
    let revisedtime = txtval -currtime;
    if(txtval >= currtime)
    {
        setTimeout(() => {
            Harry1();
        }, revisedtime);
    }


}

function Harry1()
{
    console.log("You have waked up with your alarm song");
}
