console.log("We are in tutorial 59");
let sym1 = Symbol("My indentifier");  
let sym2 = Symbol("My indentifier");  

// console.log("Symbol is",sym1);
// console.log("Type of Symbol is",typeof(sym1))  // here new key word as Symbol is primitive datatype and refernce datatype

console.log(sym1 === sym2);
let a  = "abc";
let b  = "abc";
// console.log(sym1 === sym2);
console.log(a === b);
console.log(undefined === undefined);
console.log(null === null);

let k1 = Symbol("Identifier for k1");
let k2 = Symbol("Identifier for k2");
myObj = {};
myObj["name"] = "Vishwas";
myObj[4]  = "My Integer"
myObj[k1]  = "Rohan";
myObj[k2]  = "Shubham";

// console.log(myObj);
console.log(myObj[k1]);
console.log(myObj[k2]);
console.log(myObj.k1);//cannot do this to get Rohan as it is same as myObj["k1"] and it will search string k1;

// Symbols are ignored in  for in loop
for (keys in myObj)
{
    console.log(keys,myObj[keys]);
}


console.log(JSON.stringify(myObj));
