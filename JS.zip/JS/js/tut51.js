console.log("we are in now tut 51");

let nextIndex = 0;

function iterator(values) {
    return {
        next: function () {
            if (nextIndex < values.length) {
                return {
                    value: values[nextIndex++],
                    done: false
                }
            }
            else {
                return {
                    // value: values[nextIndex++],
                    done: true
                }
                // return
                // {
                //     done:true
                // }
                   
            }
        }
    }
}

const  myArray = ["Apples","Mango","Pineapple","Bhindi","Papaya"];
const fruits = iterator(myArray);
console.log(fruits.next().value);
console.log(fruits.next().value);
console.log(fruits.next().value);
console.log(fruits.next().value);
console.log(fruits.next().value);
console.log(fruits.next().value);
