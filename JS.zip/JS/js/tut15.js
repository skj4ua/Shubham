console.log(" Welcome to tut15");
let cont = document.querySelector(".container");
//  cont = cont.childNodes;
// console.log(cont);
//  console.log(cont.children);
let nodeName = cont.childNodes[1].nodeName;
let nodeType = cont.childNodes[1].nodeType;
 console.log(nodeType);
 console.log(nodeName);
// Nodes Type
// 1 Element
// 2 Attribute
// 3 Text Node
// 8 Comment
// 9 document
// 10 doc Type

let container = document.querySelector('.container');
// console.log(container.children[1].children[0].children);

// console.log(container.firstChild);
// anove will gives the first child as it is childNodes syantx
// but if we want first element then we have to use as below
// console.log(container.firstElementChild);

// console.log(container.lastChild);
// console.log(container.lastElementChild);
// console.log(container.children);
// console.log(container.childElementCount);

// console.log(container.firstElementChild.parentNode);
// console.log(container.children[1].children[0].children[1].parentElement.parentElement.parentNode);
// console.log(container.firstElementChild.nextSibling);
// next sibling will give you the next but it may be text or comment or etc..
// so if u want only the elemenents then go as below
// console.log(container.firstElementChild.nextElementSibling.nextElementSibling);