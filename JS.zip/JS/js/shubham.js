import React from 'react'
import {View,StyleSheet} from 'react-native'
import {Text} from 'react-native-elements'

const App = (props) =>
{
    return (
        <ScrollView contentContainerStyle={style.inputContainer}>
            <Text h1> Hello Gaurav</Text>
            <Text> Hello Vishal</Text>
            <Text> Hello Suraj</Text>
            <Text> Hello Ganesh</Text>
            <Text> Hello Vikas</Text>
            <Text> Hello Sonu</Text>
            <Text> Hello Rahul</Text>
            <Text> Hello Deepa</Text>

        </ScrollView>
    )
}

const style =  StyleSheet.create({
    inputContainer:{
        flex:1,
        marginTop:20,
        padding:30
    }
})

export default App;


createStacknavigator =({

    Mealnavigator:,
    Dcreennaivgote: 
},{
    defaultnavigationOptions: {
        headerTintColor:
        headerStyle
    }
})


listContainer:{  View1
    width:'80%',
    flex:1
    //  flex:1                     <View1><ScrollView><View><Text></Text></View></ScrollView><View>
}
listitem:alignitem:center scrollview(column)
listitem:{                           
                                            // <View><Text></Text></View>
    borderColor:'#ccc',
    borderWidth:1,
    padding:15,
    marginVertical:10,
    backgroundColor:'white',
    flexdirection:'row',
    justifyContent:'space-between'
}