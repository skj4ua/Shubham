console.log("Welcome to tut28");
let myobj = {
    name:"Harry",
    channel:"code with Harry",
    address:"Mars"
}
// console.log(myobj.getName());

function obj(givenname)
{
    this.name=givenname;
}
obj.prototype.getName = function()
{
    return(this.name)
}
obj.prototype.getName = function()
{
    return(this.name)
}
obj.prototype.setName = function(Name)
{
     this.name = Name;
}

let myobj2 = new obj("Rohan");
console.log(myobj2);
