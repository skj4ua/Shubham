//console.log('we are in tut7.js let dicuss about array');
let marks = [23,43,43,24,24];
//console.log(marks);
const fruits = ['orange','apple','mango'];
const mixed = ['hello',89,[3,4]];
//console.log(mixed);

const arr = new Array(23,1212,949,'kite');
//console.log(arr);
//console.log(fruits[0])
//console.log(arr.length);
//console.log(Array.isArray(arr));
arr[0] = 'Shubham';
let a = arr[0];
//console.log(a);
//console.log(marks);
let value = marks.indexOf(43);
//console.log(value)
//marks.push(53);
//marks.unshift(10000)
//marks.pop()
//marks.shift()
//marks.splice(1,3) start with position 1 and remove 3 elements
//All these changes the orginal array
//marks.reverse()
let marks2 = [3,44,55,33,67]
marks = marks.concat(marks2)
//console.log(marks)
let myobj = {
    name : 'Shubham',
    channel : 'WS',
    isActive : true,
    marks : [33,44,33,22,24]
          
}
console.log(myobj);
console.log(myobj.channel)
console.log(myobj['channel'])