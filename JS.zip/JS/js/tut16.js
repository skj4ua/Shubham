console.log(" We are in tut16 now");
let element = document.createElement('li');
let text = document.createTextNode('I am a text node');
element.append(text);
element.className = "childs";
element.id = "created";
element.href = 'https://www.google.com/'
element.setAttribute('title' , 'mytitle');
// console.log(element);
// element.innerText = "Helllo ";
// element.innerHTML = "<b>Helllo how are you</b> ";
let u1 = document.querySelector(".this");
u1.appendChild(element);
// console.log(u1);

let elem2 = document.createElement('h3');
let tnode = document.createTextNode('this is created node for elem2');
elem2.className = "elem2";
elem2.id = "elem2";

// elem2.append(tnode);
// element.replaceWith(elem2);
 let myul = document.getElementById('myul');
//  console.log(myul);
//  let f = document.getElementById('fui');
//  console.log(f);
 myul.replaceChild(element,
    document.getElementById('fui'));
myul.removeChild(document.getElementById('lui'));

let pr = elem2.getAttribute('id');
console.log(pr,elem2);
let cr = elem2.hasAttribute('df')
elem2.removeAttribute('id');
console.log(elem2);