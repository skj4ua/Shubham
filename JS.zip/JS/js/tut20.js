console.log("This is tut20");
// add a key value pair inside localstorage
// localStorage.setItem("Name","Shubham");
// localStorage.setItem("Name2","Rohan")
// // localStorage.clear();
// // CLear the entire local storage

// // clear particular key-value pair
// localStorage.removeItem("Name2");

// //retrive an item from local storage
// let name = localStorage.getItem("Name");
// // console.log(name);

// let imp = ['adrak','pyaz','bhindi'];
// localStorage.setItem('sabzi',JSON.stringify(imp));
// name = JSON.parse(localStorage.getItem('sabzi'));
// console.log(name[0]);

/// Session Storage
// sessionStorage.setItem("SessionName","Shubham");
// sessionStorage.setItem("SessionName2","Rohan")
// sessionStorage.setItem('Sessionsabzi',JSON.stringify(imp))

