//console.log("We are  at tut6");
const name = 'Shubham';
const greeting = 'Good Morning.';
//console.log(greeting + name)
let html;
html = "<h1> this is heading</h1>" +
        "<p> this is my para</p>"
html = html.concat('this',' str2')
// console.log(html)
// console.log(name.length);
//console.log(html.toLocaleLowerCase());
//console.log(html.toUpperCase());
//console.log(html)
//console.log(html[1]);
//console.log(html.indexOf('h1'));
//console.log(html.indexOf('<'));
//console.log(html.lastIndexOf('<'));
//console.log(html.charAt(1));
//console.log(html.endsWith('strkdk2'));
//console.log(html.includes('is'));
//console.log(html.substring(0,3));
//console.log(html.slice(0,4));
//console.log(html.split(' '));
//console.log(html.replace('this' ,'it'));
let fruit1 = 'Orange'
let fruit2 = 'Apple'
let myHtml= `Hello ${name} ${greeting} ${"How are u"}
             <h1> This is heading </h1>
             <p> You like ${fruit1} and 
             ${fruit2}`;
document.body.innerHTML = myHtml;

//let a = `Welcome ${name} to our page. \n
//        ${greeting}
//       We hope you like your application.
//     ${"GoodBye"}`;

//document.body.innerHTML = a;       



//var a = "shubham"
//c = Number(a)
//console.log(c)
//var b = String(7979)
//console.log(b)


