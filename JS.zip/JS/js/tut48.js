console.log("This is tutorial 48");
// Regular Expression
    //Basic function
    //Metacharacter Symbol
    

// const regex = /^h/i;
//Character Sets -- we use []
let regex = /H[a-z]rry/ // can be any charcater from a-z
regex = /H[azy]rry/ // can  be an a,z or y
regex = /H[^azy]rry/ // cannot be any of a,z,y
regex = /H[^azy]rr[xyz]/ // cannot be a,z,y and can be x,y,z
regex = /H[a-zA-Z]rr[yu0-9][0-9]/ //we can have as many char sets as we want


//Quantifer -- we use {}
regex = /Har{2}y/ // r can occur excatly 2 times
regex = /Har{0,2}y/ // r can occur excatly 0- 2(0,1,2) times

//Grouping -- we use paranthesis for grouping ()
regex = /(har){2}([0-9]r){3}/



let str = "Harry Bhai";
str = 'harhar0r1r2r3'
let result = regex.exec(str);
console.log("result of exec is",result);

if(regex.test(str))
{
    console.log(`The string ${str} matches the expression ${regex.source}`)
}

else {
    console.log(`The string ${str}  does not  match the expression ${regex.source}`)
}