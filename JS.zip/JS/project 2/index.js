console.log("This is index.js");
//Constructor
function Book(name, author, type) {
    this.name = name;
    this.author = author;
    this.type = type;
}

// display constructor
function Display() {

}

//add method to display prototype
Display.prototype.add = function (book) {
    console.log("Adding to UI");
    let tableBody = document.getElementById("tablebody");
    console.log(tableBody);
    let uistring = `<tr>
                        <td>${book.name}</td>
                        <td>${book.author}</td>
                        <td>${book.type}</td>
                    </tr>`;

    tableBody.innerHTML += uistring;
    console.log(uistring);
}
Display.prototype.clear = function () {
    let libraryform = document.getElementById('libraryform');
    libraryform.reset();


}
Display.prototype.validate = function (book) {
    if (book.name.length > 2 && book.author.length > 2) {
        return true;
    }
    else {
        return false;
    }

}
Display.prototype.show = function (type, usermesage) {
    let message = document.getElementById("message");
    console.log(message);
    util = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
  <strong> Message: </strong> ${usermesage}
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> `
    message.innerHTML = util;

}



// add submit event listener
let libraryform = document.getElementById('libraryform');
libraryform.addEventListener('submit', libraryFormSubmit);

function libraryFormSubmit(e) {

    console.log("you have submit the library form");
    e.preventDefault();
    let name = document.getElementById("bookName").value;
    let author = document.getElementById("authorname").value;
    let fictional = document.getElementById("fictional");
    let programming = document.getElementById("programming");
    let cooking = document.getElementById("cooking");
    let type;
    if (fictional.checked) {
        type = fictional.value;
    }
    else if (programming.checked) {
        type = programming.value;
    }
    else if (cooking.checked) {
        type = cooking.value;
    }
    let book = new Book(name, author, type);
    console.log(book);

    let display = new Display();
    if (display.validate(book)) {
        display.add(book);
        display.clear();
        display.show('message', 'Your book is successfully added');
    }
    else {
        display.show('failure', " Sorry!! Your book is not added");
    }

    let notes1 = localStorage.getItem("notes1");
    // console.log(addTxt);
    if (notes1 == null) {
        notesObj = [];
    }
    else {
        notesObj = JSON.parse(notes);
    }

    //  notesObj.push(addTxt.value);
    notesObj.push(book);
    localStorage.setItem("notes", JSON.stringify(notesObj));
}