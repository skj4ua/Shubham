console.log("welcome to notes app");
showNotes();
//If user adds a note, add it to localstorage
let addBtn = document.getElementById("addbtn");
addBtn.addEventListener("click", function (e) {
    let addTxt = document.getElementById("addTxt");
    let addtitle =document.getElementById("addtitle");
    let notes = localStorage.getItem("notes");
    // console.log(addTxt);
    if (notes == null) {
        notesObj = [];
    }
    else {
        notesObj = JSON.parse(notes);
    }
    myobj = {
        text:addTxt.value,
        title:addtitle.value
    }
    //  notesObj.push(addTxt.value);
    notesObj.push(myobj);
    localStorage.setItem("notes", JSON.stringify(notesObj));
    addTxt.value = "";
    addtitle.value = "";
    console.log(notesObj);
    showNotes();
});
// add notes appers in notes below
function showNotes() {
    let notes = localStorage.getItem("notes");
    if (notes == null) {
        notesObj = []
    }
    else {
        notesObj = JSON.parse(notes);
    }

    let html = "";
    notesObj.forEach(function(element, index) {

        html += `<div class="notecard my-2 mx-2 card" style="width: 18rem;">
    <div class="card-body">
        <h5 class="card-title"> ${element.title}</h5>
        <p class="card-text"> ${element.text} </p>
        <button id="${index}" onclick="deleteNote(this.id)" class="btn btn-primary">Delete Notes</button>
    </div>
</div>`
    });

    let notesElm = document.getElementById('notesd');
    if (notesObj.length != 0) {
        notesElm.innerHTML = html;

    }
    else {
        notesElm.innerHTML = `Nothing to show! Use "Add a Note" section above to add notes`;
    }
}

//function to delete a note.

function deleteNote(index) {
    console.log(" I am deleting", index);
    let notes = localStorage.getItem("notes");
    if (notes == null) {
        notesObj = [];
    }
    else {
        notesObj = JSON.parse(notes);
    }
    notesObj.splice(index, 1);
    localStorage.setItem("notes", JSON.stringify(notesObj));
    showNotes();
}

// Search the notes by searching it in Search Tab

let search = document.getElementById("searchTxt");
search.addEventListener("input",function()
{
    let inputVal = search.value;
    // console.log("input event fired",inputVal);
    let noteCards = document.getElementsByClassName("notecard");
    // console.log(notesCards);
    Array.from(noteCards).forEach(function(element){
        let cardTxt = element.getElementsByTagName("p")[0].innerText;
            //  console.log(cardTxt);
        if(cardTxt.includes(inputVal)){
             element.style.display = "block";
            // element.style.backgroundColor = "red";
        }
        else{
            element.style.display = "none";
            // element.style.backgroundColor = "green";
        }      
        })
        })
/* further feature
1) Add title
2) Mark a note as Important
3) Separte notes by user
4) Sync and host to web server
*/