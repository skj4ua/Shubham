console.log("We are in project 4");
let name = document.getElementById("name");
let email = document.getElementById("email");
// let address = document.getElementById("address");
let phone = document.getElementById("phone")
// console.log(name, email, address, phone);
let validname = false;
let validemail = false;
let validphone = false;
name.addEventListener('blur', () => {

    // console.log("name is blurred");
    let regex = /^[a-zA-Z]([a-z0-9]){2,10}$/;
    let str = name.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log("Your name is valid");
        name.classList.remove('is-invalid');
        validname = true;
    }
    else {
        console.log("Your name is not valid");
        name.classList.add('is-invalid');
        validname = false;
    }

})


phone.addEventListener('blur', () => {

    // console.log("phone is blurred");
    let regex = /^[0-9]{10}$/;
    let str = phone.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log("Your phone is valid");
        phone.classList.remove('is-invalid');
        validphone = true;
    }
    else {
        console.log("Your phone is not valid");
        phone.classList.add('is-invalid')
        validphone = false;
    }

})

email.addEventListener('blur', () => {

    // console.log("email is blurred");
    let regex = /^([0-9a-zA-Z]+)@([0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    let str = email.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log("Your email is valid");
        email.classList.remove('is-invalid');
        validemail = true;
    }
    else {
        console.log("Your email is not valid");
        email.classList.add('is-invalid')
        validemail = true;
    }
})

let addBtn = document.getElementById("addBtn");
addBtn.addEventListener('click', (e) => {
    e.preventDefault();

    if (validname && validemail && validphone == true) {

        console.log("name,email and phone are valid and submitting the form");
        let success = document.getElementById("success");
        let failure = document.getElementById("danger");
        success.classList.add('show');
        // failure.classList.remove('show');
         failure.classList.remove('show');
        Harry();
    }
    else {
        console.log("name,email and phone are  not valid,Please enter the details again")
        let failure = document.getElementById("danger");
        failure.classList.add('show');
        success.classList.remove('show');
    }



})




function Harry()
{
    let notes = localStorage.getItem("notes");
    // console.log(addTxt);
    if (notes == null) {
        notesObj = [];
    }
    else {
        notesObj = JSON.parse(notes);
    }
    myobj = {
        name:name.value,
        email:email.value,
        phone:phone.value
    }
    //  notesObj.push(addTxt.value);
    notesObj.push(myobj);
    localStorage.setItem("notes", JSON.stringify(notesObj));
}