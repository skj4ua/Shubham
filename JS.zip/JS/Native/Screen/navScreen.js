import React from 'react'
import {creteStackNavigator,createAppContainer} from 'react-navigation'
import StartScreen from './pScreen'
import EndScreen from './sScreen'
import FilterScreen from './fScreen'

const MealContainer = creteStackNavigator({
 startScreen:StartScreen,
 EndScreen:EndScreen
},{
    defaultNavigationOptions:{
        tintColor:'red'
    }
});

const FilterContainer = createBottomTabnavigator({
    comNav:{screen:MealContainer,
        navigationOptions:{
            // this tabInfo provides us all the tab conf i.e color etc
            // and returns an Icon that need to be rendered
            tabBarIcon:(tabInfo) =>{
                return <Icon  name='ios-restaurant' size={25} color={tabInfo.tintColor}/>
            }
        }},
    fileterScreen:{screen:FilterScreen,
        navigationOptions:{
            // this tabInfo provides us all the tab conf i.e color etc
            // and returns an Icon that need to be rendered
            tabBarIcon:(tabInfo) =>{
                return <Icon name='ios-star' size={25} color={tabInfo.tintColor}/>
            }
        }},
},{
    tabBarOptions:{
        activeTintColor:'yellow'
    }
})

export default createAppContainer(FilterContainer)
