import React from 'react' 
import {Text,View,StyleSheet} from 'react-native'

const EndScreen = () => {
    <View>
        <Text>Hello  Everyone!!!!!!!</Text>
    </View>
}
export default EndScreen

