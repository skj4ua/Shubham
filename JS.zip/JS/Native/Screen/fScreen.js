import React from 'react' 
import {Text,View,StyleSheet} from 'react-native'

const FilterScreen = () => {
    <View>
        <Text>Hello  Everyone!!!!!!! Cool</Text>
    </View>
}
export default FilterScreen
