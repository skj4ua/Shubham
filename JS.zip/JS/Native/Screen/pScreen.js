import React from 'react' 
import {Text,View,StyleSheet} from 'react-native'
const StartScreen = props => {
    <TouchableWithOpacity onPress={() =>
    props.navigation.navigate({routeName:'EndScreen'})}>
    <View style={style.buttonContainer}>
        <Text style={style.textItem}>CLICK ME</Text>
        <Text style={style.textItem}>Submit</Text>
    </View>
    </TouchableWithOpacity>
}

const style = StyleSheet.create({
    buttonContainer:{
        width:200,
        height:100,
        paddingVertical:12,
        paddingHorizontal:30,
        backgroundColor:'pink',
        flexDirection:'row',
        justifyContent:'space-between'
        

    },
    textItem:{
        fontSize:30
    }
})

export default StartScreen