import React,{Component} from 'react'
import Aux from '../Auxilliary/Auxilliary'
import classes from './Layout.module.css'
import Toolbar from '../../component/Navigation/Toolbar/Toolbar'
import SideDrawer from '../../component/Navigation/SideDrawer/SideDrawer'
import {connect} from 'react-redux'


class Layout extends Component{
    state = {
        showDrawer :false
    }

    SideDrawerCloseHandler = () =>
    {
        this.setState({showDrawer:false})
    }

    SideDrawerToggleHandler = () =>
    {
        this.setState((prevState) =>{

            return{showDrawer:!prevState.showDrawer}
        })
    }
    render()
    { return(<Aux>
        {/* <div>Toolbar, SideDrawer and Backdrop </div> */}
         
        <Toolbar 
        isAuth={this.props.isAuth}
        drawerToggleClicked={this.SideDrawerToggleHandler}/>
         
         
        <SideDrawer 
        isAuth={this.props.isAuth}
        open={this.state.showDrawer} closed={this.SideDrawerCloseHandler}/>
        
        <main className={classes.Content}>
         
            {this.props.children}
        </main>
        </Aux>)
    

}


}

const mapStateToProps = state =>{
    return {
        isAuth: state.auth.token != null
    }
}

export default connect(mapStateToProps)(Layout);