import React, { Component } from 'react'
import Layout from  './hoc/Layout/Layout'
import BurgerBuilder from './container/BurgerBuilder/BurgerBuilder'
import Checkout from './container/Checkout/Checkout'
// import ContactData from './container/Checkout/ContactData/ContactData'
import Orders from './container/Orders/Orders'
import {Redirect, Route, Switch,withRouter} from 'react-router-dom'
import Auth from './container/Auth/Auth'
import Logout from './container/Auth/Logout/Logout'
import {connect} from 'react-redux'
import * as action from './store/action/index'
 class App extends Component {

    componentDidMount(){
        this.props.onTryAutoSignup()
    }

    render() {
        // let routes = (
        //     <Switch>
        //         <Route path='/Auth'   component={Auth}/>
        //         <Route path='/' exact component={BurgerBuilder} /> 
        //         <Redirect to='/' />
        //     </Switch>  
        // )

        // if(this.props.isAuth)
        // {
        //     routes = (
        //         <Switch>
        //          <Route path='/checkout'   component={Checkout}  />
        //          {/* <Route path='/contact-data'   component={ContactData}/> */}
        //          <Route path='/orders' component={Orders}/>
        //          <Route path='/Logout' component={Logout}/>
        //          <Route path='/Auth'   component={Auth}/>
        //          <Route path='/' exact component={BurgerBuilder} />
        //          <Redirect to='/' />
        //          </Switch>
        //     )
        //     }    
        
        return (
            <div>
               <Layout>
                   {/* {routes} */}
                   {/* <BurgerBuilder />  
                 <Checkout/> */}
                 <Switch>
                 <Route path='/checkout'   component={Checkout}  />
                 {/* <Route path='/contact-data'   component={ContactData}/> */}
                 <Route path='/orders' component={Orders}/>
                 <Route path='/Auth' component={Auth}/>
                 <Route path='/Logout' component={Logout}/>
                 <Route path='/' exact component={BurgerBuilder} />
                  </Switch>


                  

                  
                   
                 
               </Layout> 
            </div>
        )
    }
}

const mapStatetoProps = state =>{
    return {
        isAuth:state.auth.token != null
    }
}
const mapDispatchToProps = dispatch =>{
    return{
        onTryAutoSignup: () => dispatch(action.authCheckState())
    }
}
export default withRouter(connect(mapStatetoProps,mapDispatchToProps)(App));