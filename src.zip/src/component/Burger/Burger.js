import React from 'react'
import classes from './Burger.module.css'
import BurgerIngredient from '../BurgerIngredient/BurgerIngredient'
const Burger = (props) => {
    // console.log(props.ingredients)
    const transformedIngredients = Object.keys(props.ingredients)
    // console.log(transformedIngredients)
    let transformedIngredients1 =  transformedIngredients.map(igKey =>{
            // console.log(igKey)
         return [...Array(props.ingredients[igKey])].map((_,i) =>
         {
            //  console.log(igKey)
             let x =  <BurgerIngredient key={igKey + i} type={igKey}/>
            //  console.log(x)
             return(x)
         })
       
        // let x = [...Array(props.ingredients[igKey])]

        // console.log(x)
        // // let y =  [x]
        // // console.log(y)
        // return x

    })
    .reduce((arr,el) =>{
       return  arr.concat(el)
    },[]);
    // console.log(transformedIngredients1)
    if(transformedIngredients1.length === 0) {
        transformedIngredients1 = <p> Please start adding the ingredients </p>
    }
    

    return ( 
        <div className={classes.Burger}>
            <BurgerIngredient type='bread-top'/>                
            {transformedIngredients1}
            {/* <BurgerIngredient type='bacon'/>
            <BurgerIngredient type='salad'/> */}
            <BurgerIngredient type='bread-bottom'/>  
        </div>
    )


}

export default Burger;