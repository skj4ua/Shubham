import React ,{Component} from 'react'
import Aux from '../../../hoc/Auxilliary/Auxilliary'
import Button from '../../UI/Button/Button'

class OrderSummary extends Component
{
    // This could be a functional component,doesn't have to be class component 
    componentDidUpdate()
    {
        // console.log('[Order Summary] Component')
    }

    render()
    {
    const Ordersummary = Object.keys(this.props.ingredients)
    .map((igKey) => {
        return(
        <li key={igKey}>
            <span style={{textTransform:'capitalize'}}>{igKey}</span>: {this.props.ingredients[igKey]}
            </li>
        )

    })

    return(
        <Aux>
            <h3> Your  Order</h3>
            <p>Your Burger has following ingredients</p>
            <ul>
            {Ordersummary}
            <p><strong>Total Price :{this.props.totalPrice.toFixed(2)}</strong></p>
            <p> Continue to Checkout </p>
            
            </ul>
            {/* <Button btntype="Danger" onClick={props.PurcahseCancel}>CANCEl</Button>
            <Button btntype="Success" onClick={props.PurcahseContinue}>CONTINUE</Button> */}
            <Button btntype="Danger" clicked={this.props.PurcahseCancel}>CANCEL</Button>
            <Button btntype="Success" clicked={this.props.PurcahseContinue}>CONTINUE</Button>
        </Aux>
    )
}
}

export default OrderSummary
