import React from 'react'
import classes from './Logo.module.css'
import burgerLogo from '../../Assest/Image/burger-logo.png'
const Logo = (props) =>
{
    return(
        <div className={classes.Logo}>
            <img src={burgerLogo} alt="Burger-Logo"/>
        </div>
    )
}

export default Logo;