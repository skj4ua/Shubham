import React from 'react'
import classes from './Input.module.css'

const Input = (props) =>
{
    let inputElem = null
    let InputElement = [classes.InputElement];
    // InputElement.push(classes.InputElement)

    if(props.invalid && props.validation && props.touched)
    {
        InputElement.push(classes.Invalid)
    }
    let validationError = null;
    if (props.invalid && props.touched) {
    validationError = <p style={{
        color:'red'
        // margin:"0px 6px"
        // margin-left:'0px'

    }}>Please enter a valid value!</p>;
    }
    switch(props.elementtype)
    {
        case('input'):
        inputElem  = <input className={InputElement.join(' ')} 
        {...props.elementConfig} value={props.value} onChange={props.changed}/>
        break;

        case('textarea'):
        inputElem  = <textarea className={InputElement.join(' ')} 
        {...props.elementConfig} value={props.value} onChange={props.changed}/>
        break;

        case('select'):
        
            inputElem  = ( 
            <select 
            className={InputElement.join(' ')} 
            value={props.value} onChange={props.changed}>
            {props.elementConfig.options.map(option => (
                <option key={option.value} value={option.value}>
                    {option.displayvalue}
                </option>
                ))}    


            </select>)

        break;
        default: 
        inputElem  = <input className={classes.InputElement} 
        {...props.elementConfig}  value={props.value} onChange={props.changed}/>


    }
    return(
        <div className={classes.Input}>
            <label className={classes.Label}>{props.label}</label>
            {inputElem}
            {validationError}
        </div>
    )
}

export default Input;