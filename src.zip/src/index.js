 import React from 'react'
 import ReactDOM from 'react-dom'
 import   './index.css'
 import App from './App'
 import {Provider} from 'react-redux'
 import {createStore,applyMiddleware,compose,combineReducers} from 'redux'
 import burgerBuilderreducer from './store/reducer/burgerBuilderReducer'
 import orderReducer from './store/reducer/orderReducer'
 import authReducer from './store/reducer/Auth'
 import { BrowserRouter } from 'react-router-dom'
 import thunk from 'redux-thunk'
 
 const composeEnhancers = process.env.NODE_ENV === 'development' ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : null || compose
 
 const rootReducer = combineReducers({
     burgerBuilder:burgerBuilderreducer,
     order:orderReducer,
     auth:authReducer
 })
 const store = createStore(rootReducer,composeEnhancers(
     applyMiddleware(thunk)
 ))

const app = (
    <Provider store={store}>
    <BrowserRouter>
    <App/>
    </BrowserRouter>
    </Provider>
)
 ReactDOM.render(app , document.getElementById("root"))

// -------------------------------------------------------------------------
// Above is for ur Project

//-------------------------------------------------------------------------

// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import App from './Exercise2Ajax/App'
// import axios from 'axios'
// // import registerServiceWorker from './registerServiceWorker';

// axios.defaults.baseURL = 'https://jsonplaceholder.typicode.com';
// axios.defaults.headers.common['Authorization'] = 'SHUB - TOKEN';
// axios.defaults.headers.post['Content-Type']  = 'Application/json'
// axios.interceptors.request.use(request =>
//     {
//         // console.log(request)
//         return request
//     },error =>{
//         // console.log(error)
//         return Promise.reject(error)
//     });

//     axios.interceptors.response.use(response =>
//         {
//             // console.log(response)
//             return response
//         },error =>{
//             // console.log(error)
//             return Promise.reject(error)
//         });
        
// ReactDOM.render( <App />, document.getElementById( 'root' ) );
// // registerServiceWorker();

// --------------------------------------------------------------------------
// // Redux Project

// import React from 'react'
// import ReactDOM from 'react-dom'
// import   './index.css'
// import App from './Exercise_Redux/App'
// import {createStore,combineReducers,applyMiddleware} from 'redux'
// import counterReducer from './Exercise_Redux/store/reducers/counter'
// import resultReducer from './Exercise_Redux/store/reducers/result'
// import {Provider} from 'react-redux'
// import thunk from 'redux-thunk'

// // const app = (
// //    <BrowserRouter>
// //    <App/>
// //    </BrowserRouter>
// // )
 
// const rootReducers = combineReducers({
//     ctr:counterReducer,
//     res:resultReducer
// })

// const logger = store =>
// {
//     return next =>{
//         return action => {
//             console.log('[Middleware] Dispatching', action)
//             const result = next(action)
//             console.log('[Middleware ] next state' ,store.getState())
//             return result

//         }
//     }
// }
// const store = createStore(rootReducers,applyMiddleware(logger,thunk));

// ReactDOM.render(<Provider store={store}><App/></Provider> , document.getElementById("root"))
 
 
//____________________________________________________________________________

// Redux Assignmmnet_02


// import React from 'react'
// import ReactDOM from 'react-dom'
// import   './index.css'
// import App from './Assignment_Redux/App'
// import {createStore,combineReducers} from 'redux'

// import {Provider} from 'react-redux'

// const app = (
//    <BrowserRouter>
//    <App/>
//    </BrowserRouter>
// )
 
// const rootReducers = combineReducers({
//     ctr:counterReducer,
//     res:resultReducer
// })
// const store = createStore(rootReducers);

// ReactDOM.render(<Provider store={store}><App/></Provider> , document.getElementById("root"))
// ReactDOM.render(<App/>, document.getElementById("root"))
 //-----------------------------------------------------------------------------
 // React Hooks

// import React from 'react'
// import ReactDOM from 'react-dom'
// import './index.css'
// import App from './Hook_Tutorial/App'


 
// ReactDOM.render(<App/>,document.getElementById('root'))