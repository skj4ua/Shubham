import React, { Component } from 'react'
// import axios from '../../../axios'
// import {Link} from 'react-router-dom'
import axios from 'axios';
import Post from '../../../components/Post/Post'
import {Route} from 'react-router-dom'

import FullPost from '../FullPost/FullPost' 
import './Posts.css'

class Posts extends Component{
    state = {
        post: [],
        // SelectedPostId : null,
        // error:false
    }

    componentDidMount(){
        console.log(this.props)
        console.log("!!!!!!!!!!!")
        axios.get('/posts')
        .then((response) => {
            const post = response.data.slice(0,4)
            const UpdatedPost = post.map((post)=>{
                // console.log(post.id)
                return{
                    ...post,
                    author:'Max'
                }
            })
            // console.log(UpdatedPost)
          this.setState({ post:UpdatedPost})
            // console.log(response)
        })
        .catch(error =>
            {
                // this.setState({error:true})
                console.log(error)
            })
    }


    SelectPostHandler = (id) =>
    {

            // this.props.history.push({pathname:'/' + id})
            this.props.history.push('/posts/' + id)
            // this.props.history.push('/' + id)
    //     this.setState({SelectedPostId:id})
    //     console.log(id)
    }
    render()
    {
        let postdata = <p>Something went wrong!!!!</p>
        if(!this.state.error)

        { 
            // console.log(!this.state.error)
          postdata = this.state.post.map((data) =>{

              return (
            //   <Link  to={'/' + data.id}> 
              <Post 
              title={data.title}
              key={data.id}   
              author={data.author}
              clicked={() => this.SelectPostHandler(data.id)}/>
            //  </Link>
              )

        })
    }
        return(
            <>
        <section className="Posts">
                    
                    {postdata}
                </section>
                <Route path={this.props.match.url + '/:id'} exact component={FullPost}/>
                {/* <Route path='/:id' exact component={FullPost}/> */}
                </>
        )
    }

}  

export default Posts