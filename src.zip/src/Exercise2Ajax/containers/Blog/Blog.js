import React, { Component } from 'react';
// import axios from 'axios';
import {Route,NavLink,Switch, Redirect} from 'react-router-dom'
// import Post from '../../components/Post/Post';
// import FullPost from './FullPost/FullPost';
import NewPost from './NewPost/NewPost';
import Posts from './Posts/Posts'
import './Blog.css';


class Blog extends Component {
    
   
    
    
    render () {
        
        return (
            <div className="Blog">
                <header>
                    <nav>           
                        <ul>
                            {/* <li><a href="/">Home</a></li>
                            <li><a href="/new Post">New Post</a></li> */}
                            {/* // To prevent the relaoding of page within the SPA */}
                            <li><NavLink 
                            to="/posts/"
                            // to="/"
                            activeClassName={"my-active"}
                            activeStyle={{
                                color:'orange',
                                textDecoration:"underline"
                            }}
                            exact={true}>Home</NavLink></li>
                            <li><NavLink to={{
                                pathname:"/new Post",
                                exact:true,
                                hash:"#submit",
                                search:"?quick-submit=true"
                            }}>New Post </NavLink></li>
                        </ul>
                    </nav>
                </header>
                
                {/* <section>
                    <FullPost id={this.state.SelectedPostId}/>
                </section>
                <section>
                    <NewPost />
                </section> */}
                <Switch>
                <Route path='/New Post'   component={NewPost}/>
                {/* <Route path='/' component={Posts}/>       */}
                <Route path='/posts/' component={Posts}/>
                {/* <Redirect from='/' to='/posts' /> */}
                {/* <Route path='/' component={Posts} /> */}
              </Switch>
                {/* <Route path='/' exact render={() => <h1>Hello</h1>}/> */}
                {/* <Route path='/'   render={() => <h1>Hello!!! Viraj </h1>}/> */}
            </div>
        );
    }
}

export default Blog;