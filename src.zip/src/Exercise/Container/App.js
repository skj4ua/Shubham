import React, { Component } from 'react'
import Persons from  '../Component/Persons/Persons'
import  Cockpit from '../Component/Cockpit/Cockpit'
import withClass from '../hoc/WithClass'
import Aux from '../hoc/Auxillary'
import MyContext from '../Context/auth-context'
import classes from './App.module.css'

  

 class App extends Component {
state =
{
  Person : [
    {
      id:101,name:"Vivek",age:23
    },
    {
      id:102,name:"Sushant",age:25
    },
    {
      id:103,name:"Vishal",age:34
    }
  ],
  isStatus : false,
  isCounter: 0,
  authenticated:false

}

// switchnameHandler = () =>
// {
//   this.setState({
//     Person : [
//       {
//         name:"zazx",age:23
//       },
//       {
//         name:"csvsv",age:25
//       },
//       {
//         name:"djdd",age:34
//       }
//     ],
//     isStatus : false
  
//   })
// }
 
   Handler = (e,personId) =>
  {
    // console.log(personId)
    const personIndex = this.state.Person.findIndex((p) =>{
      return p.id === personId
    })

    const person1 = {...this.state.Person[personIndex]}
     
    person1.name = e.target.value
    // person1.age = 

    const  person2 = [...this.state.Person]
    person2[personIndex] = person1

    this.setState((prevstate,props) =>
    {
      return{
        Person:person2,
        isCounter:prevstate + 1
      };
    });

    
  }


  deletename = (CurrentIndex) =>{

    const Person1 = [...this.state.Person] 
    Person1.splice(CurrentIndex,1)
    this.setState({Person:Person1})
    
  }

  tooglename = ()=>
  {
    const currstatus = this.state.isStatus
    this.setState({isStatus:!currstatus})
  }

  loginHandler = () =>
  {
    this.setState({authenticated:true})
  }

  render() {
    // const style = {
    //   backgroundColor:"green",
    //   font:"inherit",
    //   border:"1px solid blue",
    //   padding:"5px",
    //   textAlign:"center",
    //   color:"white"
    // }
      let person = null
      
    if(this.state.isStatus)
    {
        person = (
          <div>
          <Persons 
          Person={this.state.Person}
          clicked={this.deletename}
          changed={this.Handler}
           />
          </div>
           )
          

        // style.backgroundColor= "red"
      
    }
     
    return (
      <Aux>
        <MyContext.Provider value={ 
          {authenticated:this.state.authenticated,
            login:this.loginHandler         
          }
        }
        > 
          
          
        
        <h1>{this.props.greeting}</h1>
        <Cockpit Person={this.state.Person} 
        status={this.state.isStatus}
        clicked={this.tooglename}
        // login={this.loginHandler}
        />
        {person}
        </MyContext.Provider>
      </Aux>
    )
  }
}


export default withClass(App,classes.App);