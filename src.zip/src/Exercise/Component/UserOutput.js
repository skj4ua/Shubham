import React, { Component } from 'react'
import './UserOutput.css'
export default class UserOutput extends Component {
    render() {
        return (
            <div className='UserOutput'>
              <p> Hello!!!! Good Morning Shubham
                  Your Username is :-{this.props.user}
                   
                   Have a Nice day!!!!!
              </p>
              {/* <p>{ this.props.userinput}</p> */}

              </div>
        )
    }
}
