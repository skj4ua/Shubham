import React, { Component } from 'react'
import {MyContext} from './Context'

export default class User extends Component {
    static contextType = MyContext;
    render() {
        console.log(MyContext)
        return (
            <div>
                <h1> User Component</h1>
                 
         
                
                <h1>Name : - {this.context.data.name} </h1>
                <h1>value : - {this.context.data.value}</h1>
                
                {<button onClick={this.context.HandleClk}>Click Here</button>
                
              }
         
                
            </div>
        )
    }
} 

