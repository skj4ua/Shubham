import React, { Component } from 'react'

export default class UserInput extends Component {
    render() {
        const  style = {
            // display:"inline-block",
            // boxSizing: "border-box",
            // width:"90%",
            border:"2px solid red",
            // margin:"auto"
            textAlign:"center"
        
            
          }
        return (
            <div style={style}>
            Username :- <input type="text"  onChange={this.props.handle} value={this.props.us} />
            </div>
        )
    }
}
