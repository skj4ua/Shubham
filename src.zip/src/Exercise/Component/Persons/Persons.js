import React from 'react'
import Person from './Person/person';

const  Persons =  (props) =>{

            return(
            props.Person.map((PerArr,index) =>{
              return <Person
              name={PerArr.name} 
              age={PerArr.age} 
              checked={()  => props.clicked(index)}
              key={PerArr.id}
               changed={(e) => props.changed(e,PerArr.id)}
              />
            })
            )}
          
      
      
       
       export default Persons