import React, { Component } from 'react'
import classes from './Person.module.css'
import Aux from '../../../hoc/Auxillary'
import withclass from '../../../hoc/WithClass'
import MyContext from '../../../Context/auth-context'
import PropTypes from 'prop-types'
 class Person extends Component {
     
     constructor(props)
     {
         super(props)
           
         this.myRef = React.createRef();

     }
     static contextType = MyContext;
     componentDidMount()
     {
        //  this.Elem.focus();
        this.myRef.current.focus()
     }
    render() {
        return (
            // <div className={classes.Person}>
             <Aux> 
                  
                {
                   
                    this.context.authenticated ? <p>Authenticated! </p> : <p>Please login</p> 
                }
                 
                <p onClick={this.props.checked}>My name is :- {this.props.name} and age is {this.props.age}</p>
                <input  
                // ref={(myRef) =>(this.Elem=myRef) }//  Type 1:-Callback Ref
                ref={this.myRef}
                type="text" 
                onChange={this.props.changed} 
                value={this.props.name} ></input>
                
                </Aux> 
            // </div>
        )
    }
}

Person.propTypes =  {
 
name:PropTypes.string.isRequired
}

Person.defaultProps =  {
 
    name:"Shubham"
 }
export default withclass(Person,classes.Person);

