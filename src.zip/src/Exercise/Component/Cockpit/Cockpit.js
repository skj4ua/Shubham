import React,{useEffect, useRef,useContext} from 'react'
import MyContext from '../../Context/auth-context'
import classes from'./Cockpit.module.css'
const Cockpit = (props) =>
{

     const Myref = useRef(null)
     const MyContext1 = useContext(MyContext)
    useEffect(() =>
    {
      Myref.current.click();
      console.log(MyContext1.login)
    },[])
     
    const assignedclasses = []
    let Arr = ''

    if(props.status)
    {
        Arr = classes.Red
    }

    if(props.Person.length <= 2)
    {
      assignedclasses.push(classes.red)
    }

    if(props.Person.length <= 1)
    {
      assignedclasses.push(classes.bold)
    }
    return(
        <div className={classes.Cockpit}>
         
    
        <h1> I am a React App</h1>
        <h2 className={assignedclasses.join(' ')}> This is our First Excercise</h2>
        <button  ref={Myref} className={Arr} onClick={props.clicked}> Toggle Person </button>
        {/* <MyContext.Consumer>
         {(context) => <button onClick={context.login}>Login Button</button>}
          </MyContext.Consumer>
          <br></br><br></br> */}
          {/* <button   onClick={props.login}>Login Button</button><br></br><br></br>  using props*/}
          {<button onClick={MyContext1.login}>Login Button</button>}
          <br></br><br></br>
          </div>

    )
}

export default Cockpit