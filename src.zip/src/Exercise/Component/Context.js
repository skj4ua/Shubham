import React, { Component } from 'react'

export const MyContext = React.createContext()
export const Provider = MyContext.Provider;