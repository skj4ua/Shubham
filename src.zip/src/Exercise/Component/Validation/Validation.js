import React from 'react'

function Validation (props) 
{
    let len = "Text is too short"
    if(props.textlength > 5)
    {
        len= "Text is too long"
    }
    return(
        <>
        <p>{props.usertext}</p>
        <p>{len}</p>
        </>
    )
}

export default Validation;