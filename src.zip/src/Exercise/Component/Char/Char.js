import React from 'react'

function Char (props){
    
    const style = {

        display:"inline-block",
        padding:"16px",
        textAlign:"center",
        margin:"16px",
        border:"1px solid black",
        backgroundColor:"blue"
    }
    return (
        <div style={style}>
            {/* <p> The entered text is</p> */}
            <p onClick={props.delchar}>{props.char}</p>

        </div>
    )
}

export default Char;