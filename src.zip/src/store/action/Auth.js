import * as actionType from './actionTypes'
import axios from 'axios'

export const authStart = () =>{
    return {
        type:actionType.AUTH_START
    }
}

export const authSuccess = (token,userId) =>{
    return{
        type:actionType.AUTH_SUCCESS,
        idToken:token,
        userId:userId
    }
}

export const authFail = (err) =>{
    return{
        type:actionType.AUTH_FAIL,
        error:err

    }
}

export const logout = () => {
    localStorage.removeItem('Token')
    localStorage.removeItem('tokenExpirationDate')
    localStorage.removeItem('userId')
    return{
        type:actionType.AUTH_LOGOUT
    }
}
export const checkAuthTimeout = (expirationTime) =>{
    return dispatch =>{
        setTimeout(() => {
            dispatch(logout())
        }, expirationTime * 1000);
    }
}

export const auth = (email,password,isSignup) => {
    return dispatch => {
        dispatch(authStart())
        const authData ={
            email:email,
            password:password,
            returnSecureToken:true  
        }
        let url = 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyA3h0kxY0lKXWSnXtuazKZOiINFAywe4bE'
        if(!isSignup)
        {
            url = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA3h0kxY0lKXWSnXtuazKZOiINFAywe4bE'
        }
        axios.post(url,authData)
        .then((response) =>{
            console.log(response)
            const tokenExpirationDate =  new Date(new Date().getTime() + response.data.expiresIn * 1000)
            localStorage.setItem('Token',response.data.idToken)
            localStorage.setItem('tokenExpirationDate',tokenExpirationDate)
            localStorage.setItem('userId',response.data.localId)

            dispatch(authSuccess(response.data.idToken,response.data.localId))
            dispatch(checkAuthTimeout(response.data.expiresIn))
        })
        .catch((err) =>{
            console.log(err)
            console.log(err.response)
            dispatch(authFail(err.response.data.error))
        })
    }

}

export const setAuthRedirectPath = (path) =>
{
    return{
        type:actionType.SET_AUTH_REDIRECT_PATH,
        path:path
    }
}


export const authCheckState = () =>{
    return dispatch =>{
        const token = localStorage.getItem('Token')
        if(!token)
        {
            dispatch(logout())
        }
        else{
            const tokenExpirationDate = new Date(localStorage.getItem('tokenExpirationDate'))
            if(tokenExpirationDate <= new Date())
            {
                dispatch(logout())
            }else {
                const userId = localStorage.getItem('userId')
                dispatch(authSuccess(token,userId))
                dispatch(checkAuthTimeout((tokenExpirationDate.getTime() - new Date().getTime()) /1000))
            }
        }
    }
}