export const ADD_INGREDIENT = 'ADD_INGREDIENT';
export const REMOVE_INGREDIENT = 'REMOVE_INGREDIENT';
export const SET_INGREDIENT = 'SET_INGREDIENT';
export const FETCH_INGRDIENTS_FAILED = 'FETCH_INGRDIENTS_FAILED'

export const PURCHASE_BURGER_START  = 'PURCHASE_BURGER_START'; // used to show spinner 
export const PURCHASE_BURGER_SUCCESS = 'PURCHASE_BURGER_SUCCESS';
export const PURCHASE_BURGER_FAIL    = 'PURCHASE_BURGER_FAIL';

export const PURCHASE_INIT = 'PURCHASE_INIT';  // used for redirecting the page once order is placed



export const FETCH_BURGER_START = 'FETCH_BURGER_START';
export const FETCH_BURGER_SUCCESS = 'FETCH_BURGER_SUCCESS';
export const FETCH_BURGER_FAIL ='FETCH_BURGER_FAIL'


export const AUTH_START = 'AUTH_START';
export const AUTH_SUCCESS = 'AUTH_SUCCESS';
export const AUTH_FAIL ='AUTH_FAIL'
export const AUTH_LOGOUT = 'AUTH_LOGOUT'



export const SET_AUTH_REDIRECT_PATH ='SET_AUTH_REDIRECT_PATH' // is used to for either redirecting to '/' or '/checkout
