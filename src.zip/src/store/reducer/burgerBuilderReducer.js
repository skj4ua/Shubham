import * as actionType from '../action/actionTypes';
import {updateObject} from '../../shared/utility'

let  intialstate = {
    ingredients:null,
    totalPrice:50,
    error:false,
    building:false
}
const INGREDIENT_PRICES = {
  salad:10.2,
  bacon:20.0,
  meat:30.3,
  cheese:35
}

const addIngredient = (state,action) =>
{
  const updateIngredient = {[action.ingredientname] : state.ingredients[action.ingredientname] + 1}
            const updatedIngredients = updateObject(state.ingredients,updateIngredient)
            const upadatedState = {
              ingredients:updatedIngredients,
              totalPrice:state.totalPrice + INGREDIENT_PRICES[action.ingredientname],
              building:true
            }
            return updateObject(state,upadatedState)

}
const removeIngredient = (state,action) =>{
  const updateIng = {[action.ingredientname] : state.ingredients[action.ingredientname] - 1}
  const updatedIngs = updateObject(state.ingredients,updateIng)
  const upadatedSt = {
    ingredients:updatedIngs,
    totalPrice:state.totalPrice + INGREDIENT_PRICES[action.ingredientname],
    building:true

  }
  return updateObject(state,upadatedSt)   
}
const setIngredient = (state,action) => {
  return updateObject(state,{ingredients:{
    salad:action.ingredients.salad,
    bacon:action.ingredients.bacon,
    cheese:action.ingredients.cheese,
    meat:action.ingredients.meat
  },
  totalPrice:50,
  error:false,
  building:false
})
}

const fetchIngredient = (state,action) =>{
  return updateObject(state,{error:true}) 
}


const reducer = (state = intialstate, action) =>{

        switch(action.type)
        {
          case actionType.ADD_INGREDIENT:return addIngredient(state,action)
            
          // return{
          //         ...state,
          //         ingredients:{
          //             ...state.ingredients,
          //            [action.ingredientname] : state.ingredients[action.ingredientname] + 1
          //         },

          //         totalPrice:state.totalPrice + INGREDIENT_PRICES[action.ingredientname]

          //       }
          case actionType.REMOVE_INGREDIENT:return removeIngredient(state,action)
            
          
          
          // return{
              //   ...state,
              //   ingredients:{
              //       ...state.ingredients,
              //      [action.ingredientname] : state.ingredients[action.ingredientname] - 1
        
              //           },
              //           totalPrice:state.totalPrice - INGREDIENT_PRICES[action.ingredientname]    

              //         }
           case actionType.SET_INGREDIENT:return setIngredient(state,action)



            //  return{
            //      ...state,
            //      // for the sequence of the order below is done
            //      ingredients:{
            //        salad:action.ingredients.salad,
            //        bacon:action.ingredients.bacon,
            //        cheese:action.ingredients.cheese,
            //        meat:action.ingredients.meat
            //      },
            //      totalPrice:50,
            //      error:false
            //    }
            //  }

            case actionType.FETCH_INGRDIENTS_FAILED:return fetchIngredient(state,action)
                       
              // return{
              //     ...state,
              //      error:true
              //   }
               
                      
           default:return state
           }        
          }
        

export default reducer