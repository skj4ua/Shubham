import * as actionTypes from '../action/actionTypes'
import {updateObject} from '../../shared/utility'

const initalstate = {
    order:[],
    loading:false,
    purchased:false
}

const purchaseInit = (state,action) =>{
    return   updateObject(state,{purchased:false})
}

const purchaseBurgerStart = (state,action) => {
    return updateObject(state,{ loading:true})
}

// const purchaseBurgerSuccess = (state,action) =>
// {
//     const newOrder = updateObject(action.orderData,{ id:action.orderId})
//                 //    const  newOrder = {
//                 //         ...action.orderData,
//                 //         id:action.orderId,
                        
//                 //     }

//                     return updateObject(state,{                 
//                         loading:false,
//                         purchased:true,
//                         order:state.order.concat(newOrder) })
// }
const purchaseBurgerFail = (state,action) => 
{
    return updateObject(state,{loading:false})
}

const fetchBurgerStart = (state,action) =>{

    return updateObject(state,{loading:true})
} 
const fetchBurgerSuccess = (state,action) =>{
    return updateObject(state,{ 
        order:action.orders,
        loading:false})
} 
const fetchBurgerFail = (state,action) =>{
    return updateObject(state,{loading:false})
}
const reducer = (state = initalstate,action) =>{
        switch(action.type)
        {
            case actionTypes.PURCHASE_INIT:return purchaseInit(state,action)

            
                // return{
                //     ...state,
                //     purchased:false
                // }
            case actionTypes.PURCHASE_BURGER_START:purchaseBurgerStart(state,action)
               
                // return{
                //     ...state,
                //     loading:true
                // }
            
            case actionTypes.PURCHASE_BURGER_SUCCESS:
                // return purchaseBurgerSuccess(state,action)
                {

                   
                   const  newOrder = {
                        ...action.orderData,
                        id:action.orderId,
                        
                    }

             
                    return{
                        ...state,
                        loading:false,
                        purchased:true,
                        order:state.order.concat(newOrder)                
                    }
                }
            case actionTypes.PURCHASE_BURGER_FAIL:return purchaseBurgerFail(state,action)
                                    
                    // return {
                    //     ...state,
                    //     loading:false
                    // }
                

            case actionTypes.FETCH_BURGER_START:return fetchBurgerStart(state,action)
                
                    
                    // return{
                    //     ...state,
                    //     loading:true
                    // }
                
            case actionTypes.FETCH_BURGER_SUCCESS:return fetchBurgerSuccess(state,action)
                    
                        
                        // return{
                        //     ...state,
                        //     order:action.orders,
                        //     loading:false
                        // }
                    
            case actionTypes.FETCH_BURGER_START:return fetchBurgerFail(state,action)
                        
                            
                            // return{
                            //     ...state,
                            //     loading:false
                            // }
                                  
            default:return state        
        }
}

export default reducer 