import React, { Component } from 'react'
import Button from '../../../component/UI/Button/Button'
import classes from './ContactData.module.css'
import Spinner from '../../../component/UI/Spinner/Spinner'
import axios from '../../../axios-orders'
import Input from '../../../component/UI/Input/Input'
import {connect} from 'react-redux'
import WithErrorHandler from '../../../hoc/WithErrorHandler/WithErrorHandler'
import * as action from '../../../store/action/index'

 class ContactData extends Component {
     state = {
        orderForm:
        {
            
                name:{
                    elementtype:"input",
                    elementConfig:{
                        type:"text",
                        placeholder:"Your Name"
                    },
                    value:'',
                    validation:{
                        Required:true
                    },
                    valid:false,
                    touched:false
                },
                Area:{
                    elementtype:"input",
                    elementConfig:{
                        type:"text",
                        placeholder:"Your Area"
                    },
                    value:'',
                    validation:{
                        Required:true
                    },
                    valid:false,
                    touched:false
                },
                Zipcode:{
                    elementtype:"input",
                    elementConfig:{
                        type:"text",
                        placeholder:"Your Pincode"
                    },
                    value:'',
                    validation:{
                        Required:true,
                        minlength:5,
                        maxlength:10,
                        isNumeric:true

                    },
                    valid:false,
                    touched:false
                },
                Country:{
                    elementtype:"input",
                    elementConfig:{
                        type:"text",
                        placeholder:"Your Country"
                    },
                    value:'',
                    validation:{
                        Required:true
                    },
                    valid:false,
                    touched:false
                },
                email:{
                    elementtype:"input",
                    elementConfig:{
                        type:"email",
                        placeholder:"Your E-mail"
                    },
                    value:'',
                    validation:{
                        Required:true,
                        isEmail:true
                    },
                    valid:false,
                    touched:false
                },
                deliverymethod:{
                    elementtype:"select",
                    elementConfig:{
                        options:[
                            {value:'fast',displayvalue:'Fast'},
                            {value:'cheap',displayvalue:'Cheap'}
                        ]
                    },
                    validation:{
                        
                    },
                    value:'Fast',
                    valid:true

                },
        },
        //  loading:false,
         formIsvalid:false
     }

     orderHandler  = (e) =>
     {
         e.preventDefault()
        //  console.log(this.props.ingredients)
        
        const formData = {}
        for (let formElementIdnetifier in this.state.orderForm)
        {
            formData[formElementIdnetifier] = this.state.orderForm[formElementIdnetifier].value
        }

        // console.log(formData)


        //  this.setState({loading:true})
        const order = {
            ingredients: this.props.ings,
            price:this.props.price,
            orderData:formData,
            userId:this.props.userId

            }
        
            this.props.onOrderBurger(order,this.props.token)
        //  axios.post('/orders.json',order)
        //  .then(response =>{
        //      this.setState({loading:false})
        //      this.props.history.push('/') // history is not present here as we use render
        //      // so we can handle it by passing the props or withRouter hoc
        //     //  console.log(response)
        //  })
        //  .catch(error =>{
        //     this.setState({loading:false})
        //     //  console.log(error)
        //  })


     }

     checkValidation = (value,rules) =>
     {
        let isValid = true

        if(!rules)
        {
            return true
        }
        
        if(rules.Required)
        {
            isValid = value.trim() != '' && isValid;

        }

        if(rules.minlength)
        {
            isValid = value.length >= rules.minlength && isValid;
        }

        if(rules.maxlength)
        {
            isValid = value.length <= rules.maxlength && isValid;
        }

        if(rules.isEmail) {
            const pattern = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/
            isValid=pattern.test(value) && isValid
        }

        if(rules.isNumeric) {
            const pattern = /^\d+$/
            isValid=pattern.test(value) && isValid
        }

        return isValid
     }

     InputChangeHandler(e,Indentifier)
     {
         const updatedOrderForm = {
             ...this.state.orderForm
         }

         const UpdatdedFormElement = {
            ...updatedOrderForm[Indentifier]

         }

         // Note :- there we have first copied the entire state  object in updatedOrderForm
         // but it does not create a deep clone(it just copied the pointer of the other object inside it ) 
         // it mutates orginal state hence we have again created a clone for the selected
         // Indentifier so that the value of state are not directly overwritten


         UpdatdedFormElement.value = e.target.value
         UpdatdedFormElement.valid = this.checkValidation(UpdatdedFormElement.value,UpdatdedFormElement.validation)
         UpdatdedFormElement.touched = true
         updatedOrderForm[Indentifier] = UpdatdedFormElement
        //  console.log(UpdatdedFormElement)
        let isValid = true
        for(let identifier in updatedOrderForm)
        {
            isValid = updatedOrderForm[identifier].valid && isValid

            // additonal cond added so that when both are true then only
            // make the value otherwise it creates issue with previous input ele val

        }
        console.log(isValid)
         this.setState({orderForm:updatedOrderForm,formIsvalid:isValid})


     }


    render() {
        const formElementArray = [];
        for(let key in this.state.orderForm)
        {
            formElementArray.push({
                id:key,
                Config:this.state.orderForm[key]
            })
        }
        let form = (
                //  console.log(this.props.loading,"11")      
            <form>
                {/* <Input inputtype={'input'}  type='text' name='name' placeholder='Your Name'/>
                <Input inputtype={'input'}  type='email' name='email' placeholder='Your Mail'/>
                <Input inputtype={'input'}  type='text' name='street' placeholder='Your Street'/>
                <Input inputtype={'input'}  type='text' name='postalcode' placeholder='Your PostalCode'/>
                <Button btntype='Success' clicked={this.orderHandler}>ORDER</Button> */}
                
                    {formElementArray.map(formElem =>{
                    return <Input key={formElem.id}
                     elementtype={formElem.Config.elementtype}
                     elementConfig={formElem.Config.elementConfig}
                     value={formElem.Config.value} 
                     invalid={!formElem.Config.valid}
                     validation={formElem.Config.validation}
                     touched={formElem.Config.touched}
                     changed={(e) => this.InputChangeHandler(e,formElem.id)}/>
                })}
                <Button btntype='Success' disabled={!this.state.formIsvalid} clicked={this.orderHandler}>ORDER</Button>
            </form> 
            )

        if(this.props.loading)
        {
            // console.log(this.props.loading,"22") 
            form=<Spinner/>
        }
        return (
            
            <div className={classes.ContactData}>
                <h4>Enter your Contact Details</h4>
                {form}
            </div>
        )
    }
}

const mapStatetoProps = (state) =>{
    return{
        ings:state.burgerBuilder.ingredients,
        price:state.burgerBuilder.totalPrice,
        loading:state.order.loading,
        token:state.auth.token,
        userId:state.auth.userId
        
    }
}

const mapDispatchToprops = (dispatch) => {
    return {
        onOrderBurger : (orderData,token) => dispatch(action.purchaseBurger(orderData,token))
    }
}
export default connect(mapStatetoProps,mapDispatchToprops)(WithErrorHandler(ContactData,axios));
