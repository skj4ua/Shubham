import React, { Component } from 'react'
import CheckoutSummary from '../../component/Order/CheckoutSummary/CheckoutSummary'
import ContactData from './ContactData/ContactData';
import {Route,Redirect} from 'react-router-dom'
import {connect} from 'react-redux'
// import * as action from '../../store/action/index'

 class Checkout extends Component {
    //  state = {
    //      ingredients:null,
    //      totalPrice:null
    //  }


    // componentWillMount() {
    //     // const query = new URLSearchParams(this.props.location.search);
    //     // const ingredients = {};
    //     // let price = 0;
    //      //console.log(query.entries()) it is returning just an iterator so that we can
    //    // iterate over for of loop to get it values

    //     for (let param of query.entries()) {
    //         // ['salad', '1']
    //         // console.log(param[0])
    //         if(param[0] === 'price')
    //         {
    //             price=param[1];
    //         }
    //         else{
    //         ingredients[param[0]] = +param[1];
    //         }
            
    //     }
    //     // console.log(ingredients)
    //     this.setState({ingredients: ingredients ,totalPrice:price });
    // }

    //  componentWillMount () {
    //      this.props.onInitpurchase()
    //  }will not be able to update state or props

     checkoutCanceledhandler = () =>
     {
         this.props.history.goBack();
     }

     checkoutContinuehandler = () =>
     {
        //  console.log(this.props.match)
         this.props.history.push(this.props.match.url + '/contact-data')
     }
    render() {
        // console.log(this.props.ings)
        let summary = <Redirect to='/' />
        if (this.props.ings)
        { 
            const purchasedDirect = this.props.purchased ? <Redirect to='/' /> :null
            summary= 
            (<div>
                {purchasedDirect}
            <CheckoutSummary 
            ingredients={this.props.ings}
            checkoutCanceledhandler={this.checkoutCanceledhandler}
            checkoutContinuehandler={this.checkoutContinuehandler}
            />
            <Route 
            path={this.props.match.url + '/contact-data' } 
            component={ContactData} /> 

           
            </div>)
        }
        return (
            <div>

                {summary}
                {/* <CheckoutSummary 
                ingredients={this.props.ings}
                checkoutCanceledhandler={this.checkoutCanceledhandler}
                checkoutContinuehandler={this.checkoutContinuehandler}
                />
                <Route 
                path={this.props.match.url + '/contact-data' } 
                component={ContactData} />  */}

               {/* render={(props)=> (<ContactData 
                ingredients={this.state.ingredients}
               price={this.state.totalPrice}  */}
            {/* //    {...props} 
            // props ar here passed to contactdata in this contactdata
                //we want to use to the history or match property provide as props by the 
                //Router and it is not present as this component is render as nested/and 
                //used instead of component property */}
               
            

               
            </div>
        
        )}
        }
    

const mapStatetoProps = (state) =>{
    return{
        ings:state.burgerBuilder.ingredients,
        purchased:state.order.purchased
        
    }
}


        
    
    
    export default connect(mapStatetoProps)(Checkout);


// ------------------------------------------------------------------------
// import React, { Component } from 'react';
// // import CheckoutSummary from '../../component/Order/CheckoutSummary/CheckoutSummary'
// import CheckoutSummary from '../../component/Order/CheckoutSummary/CheckoutSummary';

// class Checkout extends Component {
//     state = {
//         ingredients: {
//             salad: 1,
//             meat: 1,
//             cheese: 1,
//             bacon: 1
//         }
//     }

//     componentDidMount() {
//         const query = new URLSearchParams(this.props.location.search);
//         const ingredients = {};
//         for (let param of query.entries()) {
//             // ['salad', '1']
//             ingredients[param[0]] = +param[1];
//         }
//         this.setState({ingredients: ingredients});
//     }

//     checkoutCancelledHandler = () => {
//         this.props.history.goBack();
//     }

//     checkoutContinuedHandler = () => {
//         this.props.history.replace('/checkout/contact-data');
//     }

//     render() {
//         return (
//             <div>
//                 <CheckoutSummary 
//                     ingredients={this.state.ingredients}
//                     checkoutCancelled={this.checkoutCancelledHandler}
//                     checkoutContinued={this.checkoutContinuedHandler}/>
//             </div>
//         );
//     }
// }

// export default Checkout;
