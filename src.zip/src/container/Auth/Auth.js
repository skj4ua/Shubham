import React, { Component } from 'react'
import Input from '../../component/UI/Input/Input'
import Button from '../../component/UI/Button/Button'
import classes from './Auth.module.css'
import Spinner from '../../component/UI/Spinner/Spinner'
import {connect} from 'react-redux'
import * as action from '../../store/action/index'
import { Redirect } from 'react-router'

class Auth extends Component {
    state = {
        controls:{
            email:{
                elementtype:"input",
                elementConfig:{
                    type:"email",
                    placeholder:"Your Email Address"
                },
                value:'',
                validation:{
                    Required:true,
                    isEmail:true
                },
                valid:false,
                touched:false
            },
            password:{
                elementtype:"input",
                elementConfig:{
                    type:"password",
                    placeholder:"Password"
                },
                value:'',
                validation:{
                    Required:true,
                    minlength:7
                },
                valid:false,
                touched:false
            },
            
        },
        isSigup:true
    }


    checkValidation = (value,rules) =>
     {
        let isValid = true

        if(!rules)
        {
            return true
        }
        
        if(rules.Required)
        {
            isValid = value.trim() !== '' && isValid;

        }

        if(rules.minlength)
        {
            isValid = value.length >= rules.minlength && isValid;
        }

        if(rules.maxlength)
        {
            isValid = value.length <= rules.maxlength && isValid;
        }

        if(rules.isEmail) {
            const pattern = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/
            isValid=pattern.test(value) && isValid
        }

        if(rules.isNumeric) {
            const pattern = /^\d+$/
            isValid=pattern.test(value) && isValid
        }
        return isValid
     }

     InputChangeHandler = (event,controlName) =>{
         const  updatedControls ={
            ...this.state.controls,
            [controlName]:{
                ...this.state.controls[controlName],
                value:event.target.value,
                valid:this.checkValidation(event.target.value,this.state.controls[controlName].validation),
                touched:true
            }
         }
         this.setState({controls:updatedControls})
     }

     submitHandler = (event) =>{
        event.preventDefault();
        // console.log("Submittimg the form")
         

        this.props.Auth(this.state.controls.email.value,this.state.controls.password.value,this.state.isSigup)
    }

    switchAuthModeHandler = () =>{
        this.setState(prevState =>{
            return {isSigup:!prevState.isSigup}
        })
    }

    componentDidMount(){
        if(!this.props.buildingBurger  && this.props.authRedirectPath != '/')
        {
            this.props.onSetAuthRedirectPath()
        }
    }
    render() {
        // console.log("Auth Component")
        const formElementArray = [];
        for(let key in this.state.controls)
        {
            formElementArray.push({
                id:key,
                Config:this.state.controls[key]
            })
        }

        let  form = (
             
        <form>
                       
                {formElementArray.map(formElem =>{
                return <Input key={formElem.id}
                 elementtype={formElem.Config.elementtype}
                 elementConfig={formElem.Config.elementConfig}
                 value={formElem.Config.value} 
                 invalid={!formElem.Config.valid}
                 validation={formElem.Config.validation}
                 touched={formElem.Config.touched}
                 changed={(e) => this.InputChangeHandler(e,formElem.id)}/>
            })}
            
            </form> 
            )
            
            if(this.props.loading)
            {
                form = <Spinner/>
            }

            let errorMessage = null 
            if (this.props.error) 
            {
                errorMessage = (
                    <p>{this.props.error.message}</p>
                )
            }

            let authenticatedRedirect =  null
            if(this.props.auth)
            {
                authenticatedRedirect = <Redirect to={this.props.authRedirectPath} />
            }
        return (
            <div className={classes.Auth}>
                    {authenticatedRedirect}
                    {errorMessage}
                    <form onSubmit={this.submitHandler}>
                    {form}
                    <Button btntype="Success"  > SUBMIT</Button>
                    </form>
                    <Button 
                    clicked={this.switchAuthModeHandler}
                    btntype="Danger" >
                         SWITCH TO {this.state.isSigup ? 'SIGNUP' : 'LOGIN'}
                         </Button>
                
            </div>
        )
    
}
}

const mapStateToProps = state => {
    return {
        loading:state.auth.loading,
        error:state.auth.error,
        auth:state.auth.token != null,
        buildingBurger:state.burgerBuilder.building,
        authRedirectPath:state.auth.authRedirectPath 
    }
}
const mapDispatchToProps = dispatch =>{
    // console.log('dispatching')
    return {
        
        Auth :(email,password,isSignup) => dispatch(action.auth(email,password,isSignup)),
        onSetAuthRedirectPath:() => dispatch(action.setAuthRedirectPath('/'))
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Auth)
