import React, { Component } from 'react'
import Order from '../../component/Order/Order'
import axios from '../../axios-orders'
import WithErrorHandler from'../../hoc/WithErrorHandler/WithErrorHandler'
import * as action from '../../store/action/index'
import {connect} from 'react-redux'
import Spinner from '../../component/UI/Spinner/Spinner'
 class Orders extends Component {

    // state = {
    //     orders: [],
    //     loading:true
    // }
    componentDidMount(){

        this.props.onFetchOrders(this.props.token,this.props.userId)
        // axios.get('./orders.json')
        // .then(res => {
        //     // console.log(res.data)
        //     const fetchOrders = []
        //     for (let key in res.data)
        //     {
        //         fetchOrders.push({
        //             ...res.data[key],
        //             id:key
        //         })
        //         // console.log(res.data[key],key)
        //     }
        //     this.setState({loading:false, orders:fetchOrders})
        // })
        // .catch(err =>{
        //     this.setState({loading:false})
        // })

    }
    render() {
        // console.log(this.props.orders)
        // console.log(this.state.orders[0].ingredients)

        let orders = null
        if(this.props.loading)
        {

             orders = <Spinner />
        }

        if(this.props.orders)
        {
            orders = this.props.orders.map(order =>{
                return  <Order 
                key={order.id} 
                ingredients={order.ingredients}
                price={+order.price}
                />
             })
        }
        return (
            <div>
            {orders}
            </div>
        )
            
        
    }
}

const mapStatetoProps = state =>{
    return {
        orders:state.order.order,
        loading:state.order.loading,
        token:state.auth.token,
        userId:state.auth.userId
    }
}
const mapDispatchToProps = dispatch => {
    return {
        onFetchOrders : (token,userId) => dispatch(action.fetchBurger(token,userId))
    }
}


export default connect(mapStatetoProps,mapDispatchToProps)(WithErrorHandler(Orders,axios))
