import React from 'react';

import {configure,shallow} from 'enzyme';
import Adapater from 'enzyme-adapter-react-16'
import { BurgerBuilder } from './BurgerBuilder';
import BuildControls from '../../component/Burger/BuildControls/BuildControls'


configure({adapter:new Adapater()})

describe('<BurgerBuilder/>', ()=>{
    let wrapper;
    beforeEach(()=>{
        wrapper = shallow(<BurgerBuilder onInitingrsdients={()=>{}} />)
    })
    it('should render <Buildcontrols/> when receiving ingredients',()=>{
        wrapper.setProps({ings:{salad}})
        expect(wrapper.find(BuildControls)).toHaveLength(1)
    })
})



