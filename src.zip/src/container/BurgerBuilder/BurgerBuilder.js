import React, { Component } from 'react'
import Aux from '../../hoc/Auxilliary/Auxilliary'
import Burger from '../../component/Burger/Burger'
import BuildControls from '../../component/Burger/BuildControls/BuildControls'
import Modal from '../../component/UI/Modal/Modal'
import OrderSummary from '../../component/Burger/OrderSummary/OrderSummary'
import Spinner from '../../component/UI/Spinner/Spinner'
import WithErrorHandler from '../../hoc/WithErrorHandler/WithErrorHandler'
import axios from '../../axios-orders'
import {connect} from 'react-redux'
// import * as actionType from '../../store/action/actionTypes'
// import reducer from '../../store/reducer/burger'
import * as action  from '../../store/action/index'
// import { Redirect } from 'react-router'



 export class BurgerBuilder extends Component {
     state = {
        //  ingredients: {
        //      salad:0,
        //      bacon:0,
        //      cheese:0,
        //      meat:0
        //  },
        //  ingredients:null,
        //  totalPrice:50,
        //  purchaseable:false,  // indicates order now button is enable or disable
         purchasing:false    // indicates the Modal should appears or not
        //  loading:false,     //click on continue button then sometime it loads
        //  error:false       //error message should be show when the get request failed
     }

     componentDidMount(){

        this.props.onInitingrsdients()
        //  axios.get('https://react-myapp-burger-9ed67.firebaseio.com/ingredients.json')
        //  .then(response => {
        //         this.setState({ingredients:response.data})
        //  })
        //  .catch(error =>{
        //     this.setState({error:true})
        //  })

        }
     UpdatePurchasestate = (ingredients) =>{
        //  let ingredients = {             as we have not received the updated state 
        //      ...this.state.ingredientsn  value from below Add... and remove... methods
        //  }
         let sum = Object.keys(ingredients)
         .map((igKey) => {
             return ingredients[igKey]
         })
         .reduce((sum,el)=>{
            return sum + el
         },0)

         return sum > 0 
     }
    //  AddIngrendientHandler = (type) =>

    //  {
    //         const Oldcount = this.state.ingredients[type]
    //         const UpdatedCount = Oldcount + 1
    //         const UpdatedIngredients =  {
    //             ...this.state.ingredients
    //         }
    //         UpdatedIngredients[type] = UpdatedCount
    //         const OldPrice = this.state.totalPrice
    //         const UpdatedPrice = OldPrice + INGREDIENT_PRICES[type]
            
    //         this.setState({ingredients:UpdatedIngredients, totalPrice:UpdatedPrice})
    //         this.UpdatePurchasestate(UpdatedIngredients)
    //  }

    //  RemoveIngrendientHandler = (type) =>

    //  {
    //         const Oldcount = this.state.ingredients[type]
    //         if(Oldcount <= 0)
    //         {
    //             return 
    //         }
    //         const UpdatedCount = Oldcount - 1
    //         const UpdatedIngredients =  {
    //             ...this.state.ingredients
    //         }
    //         UpdatedIngredients[type] = UpdatedCount
    //         const OldPrice = this.state.totalPrice
    //         const UpdatedPrice = OldPrice - INGREDIENT_PRICES[type]
            
    //         this.setState({ingredients:UpdatedIngredients, totalPrice:UpdatedPrice})
    //         this.UpdatePurchasestate(UpdatedIngredients)
    //  }
    
     PurchaseHandler = () =>
     {
         if(this.props.auth) 
         {
             this.setState({purchasing:true})

         }
         else {
            //  <Redirect to='/auth'/>
            this.props.onSetAuthRedirectPath('./checkout')
            this.props.history.push('/auth')
         }
     }

     PurcahseCancelhandler = () =>
     {
         this.setState({purchasing:false})
     }

     PurcahseContinuehandler = () =>
     {
        this.props.onInitpurchase()
        this.props.history.push('/checkout')
        //  const queryParams = []
        //  for(let i in this.state.ingredients){
        //      queryParams.push(encodeURIComponent(i) + '=' + encodeURIComponent(this.state.ingredients[i]))
        //     // queryParams.push(i + '=' + this.state.ingredients[i])
        // }
        //     queryParams.push("price=" + this.state.totalPrice)
        //     // console.log(queryParams)
        //  const queryString = queryParams.join('&')
        // //  console.log(queryString)
        //  this.props.history.push({
        //      pathname:'/checkout',
        //      search:'?' + queryString

        //  })
        //----------------------------------------------------
        //  this.props.history.push('/checkout')
        //  this.setState({loading:true})
        // const order = {
        //     ingredients: this.state.ingredients,
        //     price:this.state.totalPrice,
        //     customer:{
        //         name:'Shubham Tompe',
        //         Address:{
        //             Area:"Plot no 16, Saibaba Nagar",
        //             Zipcode:"440002",
        //             Country:"India"
        //         },
        //         email:"abc@test.com"
        //     },
        //     deliverymethod:'Super-fast'

        //     }
        

        //  axios.post('/orders.json',order)
        //  .then(response =>{
        //      this.setState({loading:false,purchasing:false})
        //     //  console.log(response)
        //  })
        //  .catch(error =>{
        //     this.setState({loading:false,purchasing:false})
        //     //  console.log(error)
        //  })


        //alert('You can Continue now!!!')    
    }

    
    render() {
        
        const Disabled = {
            ...this.props.ings
        }

        for (let key in Disabled)
        {
            Disabled[key] =  Disabled[key] <=0
        }

         let orderSummary = null        
         let burger = this.props.error  ? <p>Ingredients cannot be loaded</p> :<Spinner />
         
         if(this.props.ings)
         {
             
             burger = (
            <Aux>
                <Burger  ingredients={this.props.ings}/>  
                    <BuildControls 
                    ingredientsadd =  {this.props.onAddingredient}
                    ingredientsrem = {this.props.onRemoveingredient}
                    disabled={Disabled}
                    price={this.props.price}
                    // purchase={this.state.purchaseable}
                    purchase={this.UpdatePurchasestate(this.props.ings)}
                    ordered={this.PurchaseHandler}
                    isAuth={this.props.auth}
                    
                    />
            </Aux>
        )
        orderSummary = <OrderSummary ingredients={this.props.ings}
        PurcahseCancel={this.PurcahseCancelhandler} 
        PurcahseContinue={this.PurcahseContinuehandler}
        totalPrice={this.props.price}/>
      

         }

         
    //     if(this.state.loading)
    //   {
    //       orderSummary = <Spinner/>
    //   }
    
        return (
            <Aux>
                  <Modal 
                  show={this.state.purchasing}
                  modalClosed={this.PurcahseCancelhandler}
                  >
                  {orderSummary}
                  </Modal>
                  {burger}
            </Aux>
        )
    }
}

const mapStatetoProps = (state) =>{
    return{
        ings:state.burgerBuilder.ingredients,
        price:state.burgerBuilder.totalPrice,
        error:state.burgerBuilder.error,
        auth:state.auth.token != null
    }
}

const mapDispatchtoProps = (dispatch) =>
{
    return {
    //     onAddingredient:(igname) => dispatch({type:actionType.ADD_INGREDIENT,ingredientname:igname}),
    //    onRemoveingredient:(igname) => dispatch({type:actionType.REMOVE_INGREDIENT,ingredientname:igname})
    onAddingredient:(igname) => dispatch(action.addIngredient(igname)),
    onRemoveingredient:(igname) => dispatch(action.removeIngredient(igname)),
    onInitingrsdients: () => dispatch(action.initIngredients()),
    onInitpurchase : () => dispatch(action.purchaseInit()),
    onSetAuthRedirectPath: (path) =>dispatch(action.setAuthRedirectPath(path))
}
}
export default connect(mapStatetoProps,mapDispatchtoProps)(WithErrorHandler(BurgerBuilder,axios));


 