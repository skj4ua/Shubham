import React, { Component } from 'react';
import {connect} from 'react-redux';

import CounterControl from '../../components/CounterControl/CounterControl';
import CounterOutput from '../../components/CounterOutput/CounterOutput';
import * as actionTypes from '../../store/action/index'

// import {increment,decrement,add,subtract,store_result,delete_result} from '../../store/action/action'

class Counter extends Component {
    state = {
        counter: 0
    }

    counterChangedHandler = ( action, value ) => {
        switch ( action ) {
            case 'inc':
                this.setState( ( prevState ) => { return { counter: prevState.counter + 1 } } )
                break;
            case 'dec':
                this.setState( ( prevState ) => { return { counter: prevState.counter - 1 } } )
                break;
            case 'add':
                this.setState( ( prevState ) => { return { counter: prevState.counter + value } } )
                break;
            case 'sub':
                this.setState( ( prevState ) => { return { counter: prevState.counter - value } } )
                break;
        }
    }

    render () {
        return (
            <div>
                <CounterOutput value={this.props.ctrl} />
                <CounterControl label="Increment" clicked={this.props.onIncrementCounter} />
                <CounterControl label="Decrement" clicked={this.props.onDecrementCounter}  />
                <CounterControl label="Add 10" clicked={this.props.InIncrementCounter}  />
                <CounterControl label="Sub 15" clicked={this.props.InDecrementCounter} />
                <hr/>
                <button onClick={()=>this.props.Onstoreresult(this.props.ctrl)}> Store Result </button>
                
                {/* <button onClick={() => this.props.Onstoreresult(this.props.ctrl)}> Store Result </button> */}
                <ul>
                    {this.props.val.map(val =>
                        {
                           return <li  key={val.id} onClick={() =>this.props.Ondeleteresult(val.id)}>{val.value}</li>
                        // return <li   onClick={this.props.Ondeleteresult}>{val}</li>
                        })}
                </ul>
            </div>
        );
    }
}

const mapStatetoProps = (state) =>{
    return{
        ctrl:state.ctr.counter,
        val:state.res.result
    }
}

const mapDispatchtoProps = dispatch =>{
    return{
        
        // onIncrementCounter : () => dispatch({type:actionTypes.INCREMENT}),
        // InIncrementCounter : () => dispatch({type:actionTypes.ADD,val:10}),
        // onDecrementCounter : () => dispatch({type:actionTypes.DECREMENT}),
        // InDecrementCounter : () => dispatch({type:actionTypes.SUBTRACT,val:15}),
        // Onstoreresult : (counterval) => dispatch({type:actionTypes.STORE_RESULT , result:counterval}),
        // Ondeleteresult: (id) => dispatch({type:actionTypes.DELETE_RESULT , resultID:id})


        onIncrementCounter : () => dispatch(actionTypes.increment()),
        onDecrementCounter : () => dispatch(actionTypes.decrement()),
        InIncrementCounter : () => dispatch(actionTypes.add(10)),
        InDecrementCounter : () => dispatch(actionTypes.subtract(15)),
        Onstoreresult : (counterval) => dispatch(actionTypes.storeResult(counterval)),
        Ondeleteresult: (id) => dispatch(actionTypes.deleteResult(id))

    }
}

export default connect(mapStatetoProps,mapDispatchtoProps)(Counter);