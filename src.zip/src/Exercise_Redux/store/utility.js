export const updateObj = (oldState,updatedValues) =>
{
    return{
        ...oldState,
        ...updatedValues
    }
}