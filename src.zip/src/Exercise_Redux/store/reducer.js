import * as actionTypes from './action'
const intialstate = {
    counter:0,
    result:[]
}

const reducer = (state = intialstate,action) =>
{
    switch(action.type)
    {
        case actionTypes.INCREMENT:
    
            const newstate = Object.assign({},state);
            newstate.counter = newstate.counter + 1;
            return newstate

        case actionTypes.DECREMENT:
        
            return{
                ...state,
                counter:state.counter - 1
            }
       

       case actionTypes.ADD:
    
        return{
            ...state,
            counter:state.counter + action.val
        }
    

    case actionTypes.SUBTRACT:
    
        return{
            ...state,
            counter:state.counter - action.val
        }


    case actionTypes.STORE_RESULT:
        
    return {
            ...state,
           result:state.result.concat({id:new Date(),value:state.counter})
        // result:state.result.concat(state.counter)
    }

    case actionTypes.DELETE_RESULT:
        // id = 2
        // const UpdateArr = [...state.result]
        // UpdateArr.splice(id,1)
        const updatedArr = state.result.filter(ele => ele.id !== action.resultID)
        return{
            ...state,
            result:updatedArr
        }
            
}

return state;
}
    


export default reducer;