import * as actionTypes from '../action/actionType'
import {updateObj} from '../utility'
const intialstate = {
    counter:0,
    
}

const reducer = (state = intialstate,action) =>
{
    switch(action.type)
    {
        case actionTypes.INCREMENT:
            return updateObj(state,{counter:state.counter + 1})
            // const newstate = Object.assign({},state);
            // newstate.counter = newstate.counter + 1;
            // return newstate

        case actionTypes.DECREMENT:
            return updateObj(state,{counter:state.counter - 1})
            // return{
            //     ...state,
            //     counter:state.counter - 1
            // }
       

       case actionTypes.ADD:
        return updateObj(state,{counter:state.counter + action.val})
        // return{
        //     ...state,
        //     counter:state.counter + action.val
        // }
    

    case actionTypes.SUBTRACT:
         return updateObj(state,{counter:state.counter - action.val})
        // return{
        //     ...state,
        //     counter:state.counter - action.val
        // }


    
            
}

return state;
}
    


export default reducer;