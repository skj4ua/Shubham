import * as actionTypes from '../action/actionType'
import {updateObj} from '../utility'

const intialstate = {
    
    result:[]
}


const deleteResult = (state,action) =>{
    console.log(state,action)
    const updatedArr = state.result.filter(ele => ele.id !== action.resultID)
    return updateObj(state,{result:updatedArr})   
}
const reducer = (state = intialstate,action) =>
{
    switch(action.type)
    {
        
    case actionTypes.STORE_RESULT:
        return updateObj(state,{result:state.result.concat({id:new Date(),value:action.result})}) 
    // return {
    //         ...state,
    //        result:state.result.concat({id:new Date(),value:action.result})
    //     // result:state.result.concat(state.counter)
    // }

    case actionTypes.DELETE_RESULT:
        // id = 2
        // const UpdateArr = [...state.result]
        // UpdateArr.splice(id,1)
        // const updatedArr = state.result.filter(ele => ele.id !== action.resultID)
        // return updateObj(state,{result:updatedArr})
        // return{
        //     ...state,
        //     result:updatedArr
        // }

        return deleteResult(state,action)
            
}

return state;
}
    


export default reducer;