export {
    increment,
    decrement,
    add,
    subtract
} from './counter';

export{
    storeResult,
    deleteResult
} from './result'

