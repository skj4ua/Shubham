import React,{useState} from 'react';

import Card from '../UI/Card';
import './IngredientForm.css';

const IngredientForm = React.memo(props => {

  // const [title, settitle] = useState('')
  // const [amount, setamount] = useState('')
  const [state, setstate] = useState({title:'',amount:''})
  const submitHandler = event => {
    event.preventDefault();
    props.addIngredients({title:state.title,amount:state.amount})
    // ...
  };


  // const TitleHandler = (e) =>
  // {
  //   // settitle(e.target.value)
  //   setstate(prevState => {
  //     return (
  //       state.title: e.target.value

  //     )
  //   })
  // }
  // const AmountHAndler= (e) =>{
  //   setamount(e.target.value)
  // }

  return (
    <section className="ingredient-form">
      <Card>
        <form onSubmit={submitHandler}>
          <div className="form-control">
            <label htmlFor="title">Name</label>
            <input type="text" 
            id="title" 
            value={state.title}
            //  onChange={event => TitleHandler(event)}
            onChange={e =>  {
              const newtitle = e.target.value
              setstate(prevState => ({
               title:newtitle,
               amount:prevState.amount
            })
            )}}/>
          </div>
          <div className="form-control">
            <label htmlFor="amount">Amount</label>
            <input type="number" id="amount" 
             value={state.amount} 
            //  onChange={event => AmountHAndler(event)}
             onChange={e => {
               const newamount = e.target.value
              setstate(prevState => ({
                amount:newamount,
              title:prevState.title
           })
           )}}
             />
          </div>
          <div className="ingredient-form__actions">
            <button type="submit">Add Ingredient</button>
          </div>
        </form>
      </Card>
    </section>
  );
});

export default IngredientForm;
