import React ,{useState} from 'react';

import IngredientForm from './IngredientForm';
import IngredientList from './IngredientList'
import Search from './Search';

function Ingredients() {
  const [useringredients, setuseringredients] = useState([])

  const addIngredients = ingredients =>
  {
    setuseringredients(previngredients =>[
      ...previngredients,
      {
          id: Math.random().toString(),
          ...ingredients
      }
    ])
  }
  return (
    <div className="App">
      <IngredientForm  addIngredients={addIngredients}/>

      <section>
        <Search />
        {/* Need to add list here! */}
        <IngredientList ingredients={useringredients} onRemoveItem={() => {}}/>
      </section>
    </div>
  );
}

export default Ingredients;
