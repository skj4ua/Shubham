import axios from 'axios';

const instance = axios.create({
    baseURL:'https://react-myapp-burger-9ed67.firebaseio.com/'
})

export default instance;